/*global $, jQuery, alert*/
/*jslint eqeq: true*/
var transId = 1;
var currentMode = "Nomal";
var mccData = [{mcc:"724", mnc:"02"}, {mcc:"208", mnc:"0"}, {mcc:"404", mnc:"01"}, {mcc:"250", mnc:"01"}];

var appIdService = 'org.tizen.inapppurchase.iapservice';
var appIdClient = 'org.tizen.inapppurchase.iapclient';
//var defaultItemGroupId = '100000031005';	//STG
var defaultItemGroupId = '100000062106';	//PRD
var g_countryList = null;
var g_requestFlag = false;


function timeout_trigger() {
	g_requestFlag = false;
}

function timeout_init() {
    setTimeout('timeout_trigger()', 20 * 1000);
}


var iap = {};
iap.listener = null;
iap.RegisterCallback = function(callback) {
	iap.listener = callback;
};

function fn_allClear() {
	$("#resultField").html("");
	
	$("#mcc").val("");
	$("#mcc").trigger("change");
	
	$("#mnc").val("");
	$("#itemGroupID").val("");
	
	$("#itemType").val("");
	$("#itemType").trigger("change");
	
	$("#developerMode").hide();
}

function fn_modeChange() {
	fn_allClear();
	
	if ($('input[name="modeRadio"]:checked').val() == 1) {
		currentMode = "Developer";
		$("#developerMode").show();
		
		if (g_countryList == null){
			fn_getCountryList();
		} else {
			fn_handleCountryList(g_countryList);	
		}
	} else {
		currentMode = "Normal";
	}
}

function fn_insertMcc() {
	var mcc = $("#mcc").val(),
		i = 0;
	
	if (mcc == "" || mcc == null) {
		$("#mnc").val("");
	} else {
		for (i = 0; i < mccData.length; i++) {
			if (mcc == mccData[i].mcc) {
				$("#mnc").val(mccData[i].mnc);
				break;
			}
		}
	}
}

function fn_showPopup(text) {
	alert('Error : ' + text);
}

function fn_errorMessage(statusCode) {
	var iStatusCode = parseInt(statusCode, 10);
	
	switch (iStatusCode) {
	case 200:
		fn_showPopup('Network error');
		break;
	case 2001:
		fn_showPopup('Service not ready forthis country');
		break;
	case 1000:
		fn_showPopup('Process error');
		break;
	case 9201:
		fn_showPopup('Item group id not found');
		break;
	case 9207:
		fn_showPopup('Item id not found');
		break;
	case 9502:
		fn_showPopup('Invalid request param');
		break;
	case 100:
		fn_showPopup('User cancel');
		break;
	case 5600:
		fn_showPopup('PG error');
		break;
	case 9291:
		fn_showPopup('No Reorder Item');
		break;
	case 9292:
		fn_showPopup('Update In-App Purchase Clinet');
		break;
	default:
		fn_showPopup('Unknow error');
		break;
	}
}

function fn_checkStatus(statusCode) {
	var iStatusCode = parseInt(statusCode, 10);
	
	switch (iStatusCode) {
	case 0:
		return true;
	default:
		fn_errorMessage(statusCode);
		return false;
	}
}

//Get Country List
function fn_getCountryList() {
	var data = {};
	data['_transactionId'] = transId++;
	iap.RequestGetCountryList(data);
}

function fn_processCountry(data, prefix) {
	var name = data[prefix + '_countryName'].toString(),
		mcc = data[prefix + '_mcc'].toString(),
		row = '';
	
	row += "<option value='" + mcc + "'>" + name + "</option>";
		
	return row;
}

// Handle Country List
function fn_handleCountryList(list) {
	var startNumber = parseInt(list._startNumber, 10),
		endNumber = parseInt(list._endNumber, 10) + 1,
		i = 0;
	
	for (i = startNumber; i < endNumber; i++) {
		$("#mcc").append(fn_processCountry(list, i));
	}
}

// Get Item List
function fn_getItemList() {
	var mcc = $("#mcc").val(),
		mnc = $("#mnc").val(),
		itemGroupId = $("#itemGroupID").val(),
		itemType = $("#itemType").val(),
		data = {};
	
	if (currentMode == "Developer") {
		if (itemGroupId == "" || itemGroupId == null) {
			alert("Insert Item Group ID.");
			return false;
		}
		
		if (itemType == '' || itemType == null) {
			itemType = '10';
		}
	} else {
		itemGroupId = defaultItemGroupId;		
		itemType = '10';
	}
	 
	data['_transactionId'] = transId++;
	data['_startNumber'] = 1;
	data['_endNumber'] = 15;
	data['_itemGroupId'] = itemGroupId;
	data['_mode'] = $('input[name="modeRadio"]:checked').val();
	data['_languageCd'] = 'eng'; 
	data['_mcc'] = mcc;
	data['_mnc'] = mnc;
	data['_itemTypeCd'] = itemType;
	iap.RequestItemInformationList(data);
}

function fn_processItem(data, prefix, purchased) {
	var name = data[prefix + '_itemName'].toString(),
		price = data[prefix + '_itemPrice'].toString(),
		purchaseDate = '',
		imageUrl = '',
		separator = '',
		row = '';
	
	name = name.substr(0, 25);
	
	if (price.indexOf('.', 0) > -1) {
		separator = '.';
	} else if (price.indexOf(',', 0) > -1) {
		separator = ',';
	}
	
	if (separator != '') {
		price = price.split(separator);
		price = price[0] + '.' + price[1].substr(0, 2);
	}
	
	if (data[prefix + '_itemImageUrl'] == undefined) {
		imageUrl = "./images/tizen_32.png";
	} else {
		imageUrl = data[prefix + '_itemImageUrl'].toString();
	}
	
	if (purchased) {
		purchaseDate = data[prefix + '_purchaseDate'].toString();
		
		row = '<tr><td rowspan="2" align="center"><img src="' + imageUrl + '" width="24px" height="24px"/></td>';
		row += '<td><b>' + name + '</b></font></td></tr>';
		row += '<tr><td align="right">' + purchaseDate.substr(0,4) + '-' + purchaseDate.substr(4,2) + '-' + purchaseDate.substr(6,2) + '</td></tr>';
	} else {
		row = '<tr><td align="center"><img src="' + imageUrl + '" width="24px" height="24px"/></td>';
		row += '<td><b>' + name + '</b><br/>' + price + ' ' + data[prefix + '_currencyUnit'] + '</td>';
		row += '<td align="right">';
		row += '<input type="button" value="BUY" onclick="javascript:fn_purchaseItem(\''
			+ data[prefix + '_itemId'] + '\', \''
			+ data[prefix + '_itemGroupId'] + '\')"/';
		row += '</td></tr>';
	}
	
	return row;
}

// Handle Item List 
function fn_handleItemList(list) {
	var startNumber = parseInt(list._startNumber, 10),
		endNumber = parseInt(list._endNumber, 10) + 1,
		row = '',
		i = 0;
	
	if (list._itemTotalCount > 0) {
		row += '<table width="100%" border="2" frame="void" rules="rows">';
		for (i = startNumber; i < endNumber; i++) {
			row += fn_processItem(list, i);
		}
		row += '</table>';
	} else {
		row = '<p>Item does not exist.</p>';
	}
	
	$("#resultField").html(row);
}

// Purchase Item
function fn_purchaseItem(itemId, itemGroupId) {
	var mcc = $("#mcc").val(), 
		mnc = $("#mnc").val(),
		data = {};
	
	data['_itemId'] = itemId;
	data['_itemGroupId'] = itemGroupId;
	data['_transactionId'] = transId++;
	data['_mode'] = $('input[name="modeRadio"]:checked').val();
	data['_languageCd'] = 'eng'; 
	data['_mcc'] = mcc;
	data['_mnc'] = mnc;
	
	if (currentMode == "Developer") {
		data['_indCarrierMode'] = "1";
	}
	
	iap.RequestPurchaseItem(data);
}

// Handle Success Purchase
function fn_handleSuccessPurchase(purchasedInfo) {
	alert('SuccesFully purchased an item : ' + purchasedInfo._itemName);
}

// Get Purchaed Item List
function fn_getPurchasedItemList() {
	var startDate = '20140101',
		endDate = '20201231',
		mcc = $("#mcc").val(),
		mnc = $("#mnc").val(),
		itemGroupId = $("#itemGroupID").val(),
		data = {};
	
	if (currentMode == "Developer") {
		if (itemGroupId == "" || itemGroupId == null) {
			alert("Insert Item Group ID.");
			return false;
		}
	} else {
		itemGroupId = defaultItemGroupId;
	}
	 
	data['_transactionId'] = transId++;
	data['_startNumber'] = 1;
	data['_endNumber'] = 15;
	data['_itemGroupId'] = itemGroupId;
	data['_mode'] = $('input[name="modeRadio"]:checked').val();
	data['_languageCd'] = 'eng'; 
	data['_mcc'] = mcc;
	data['_mnc'] = mnc;
	data['_startDate'] = startDate;
	data['_endDate'] = endDate;
	
	iap.RequestPurchasedItemInformationList(data);
}

// Handle Purchased Item List
function fn_handlePurchasedItemList(list) {
	var startNumber = parseInt(list._startNumber, 10),
		endNumber = parseInt(list._endNumber, 10) + 1,
		row = '',
		i = 0;
	
	if (list._itemTotalCount > 0) {
		row += '<table width="100%">';
		for (i = startNumber; i < endNumber; i++) {
			row += fn_processItem(list, i, true);
		}
		row += '</table>';
	} else {
		row = '<p>Item does not exist.</p>';
	}
	
	$("#resultField").html(row);
}

var IapListener = {
		OnCountryListReceived : function(statusCode, countryList) {
			if (fn_checkStatus(statusCode)) {
				fn_handleCountryList(countryList);
				g_countryList = countryList;
			}
		},
		OnItemInformationListReceived : function(statusCode, itemInformationList) {
			if (fn_checkStatus(statusCode)) {
				fn_handleItemList(itemInformationList);
			}
		},
		OnPurchaseItemReceived : function(statusCode, purchasedItemInformation) {
			if (fn_checkStatus(statusCode)) {
				fn_handleSuccessPurchase(purchasedItemInformation);
			}
		},
		OnPurchasedItemInformationListReceived : function(statusCode, purchasedItemInformationList) {
			if (fn_checkStatus(statusCode)) {
				fn_handlePurchasedItemList(purchasedItemInformationList);
			}
		}
	};

iap.SendAppControl = function(operation, applicationId, appControlData, appControlReplyCB) {
	
	if (g_requestFlag == false) {
		g_requestFlag = true;
		timeout_init();
		var pAppControl = new tizen.ApplicationControl(operation, null, null, null, appControlData);
		tizen.application.launchAppControl(pAppControl, applicationId, function() {
			console.log("success");
		}, function() {
			console.log("fail");
		}, appControlReplyCB);
	} else {
		alert("Already running! Please wait a moment");
	}
};

iap.AppControlReplyCB = {
		// Reply is sent if the requested operation is successfully delivered
		
		onsuccess : function(reply) {
			g_requestFlag = false;
			if (reply != null) {
				var data = {},
					length = reply.length,
					i = 0;
				
				for (i = 0; i < length; i++) {
					data[reply[i].key] = reply[i].value;
				}
				if (data._method == 'OnCountryListReceived') {
					iap.OnCountryListReceived(data);
				} else if (data._method == 'OnItemInformationListReceived') {
					iap.OnItemInformationListReceived(data);
				} else if (data._method == 'OnPurchaseItemReceived') {
					iap.OnPurchaseItemReceived(data);
				} else if (data._method == 'OnPurchasedItemInformationListReceived') {
					iap.OnPurchasedItemInformationListReceived(data);
				} else {
					fn_errorMessage(data._result);
				}
			}
		},
		onerror : function(reply){
			g_requestFlag = false;
		}
	};

iap.RequestGetCountryList = function(data) {
	var pAppControlData = [ new tizen.ApplicationControlData('_transactionId', [data['_transactionId']])];
	iap.SendAppControl('http://tizen.org/appcontrol/operation/iapv2/get_country_list', appIdService, pAppControlData, iap.AppControlReplyCB);
};

iap.OnCountryListReceived = function(data) {
	iap.listener.OnCountryListReceived(data._result, data);
};

iap.RequestItemInformationList = function(data) {
	var pAppControlData = [ 
	                        new tizen.ApplicationControlData('_transactionId', [ data['_transactionId'] ]),
	                        new tizen.ApplicationControlData('_startNumber', [ data['_startNumber'] ]),
	                        new tizen.ApplicationControlData('_endNumber', [ data['_endNumber'] ]),
	                        new tizen.ApplicationControlData('_itemGroupId', [ data['_itemGroupId'] ]),
	                        new tizen.ApplicationControlData('_mcc', [ data['_mcc'] ]),
	                        new tizen.ApplicationControlData('_mnc', [ data['_mnc'] ]),
	                        new tizen.ApplicationControlData('_mode', [ data['_mode'] ]),
	                        new tizen.ApplicationControlData('_languageCd', [ data['_languageCd'] ]),
	                        new tizen.ApplicationControlData('_itemTypeCd', [ data['_itemTypeCd'] ])
	                       ];
	iap.SendAppControl('http://tizen.org/appcontrol/operation/iapv2/get_item_list', appIdService, pAppControlData, iap.AppControlReplyCB);
};

iap.OnItemInformationListReceived = function(data) {
	iap.listener.OnItemInformationListReceived(data._result, data);
};

iap.RequestPurchaseItem = function(data) {
	var pAppControlData = [
	                       new tizen.ApplicationControlData('_mcc', [ data['_mcc'] ]),
	                       new tizen.ApplicationControlData('_mnc', [ data['_mnc'] ]),
	                       new tizen.ApplicationControlData('_mode', [ data['_mode'] ]),
	                       new tizen.ApplicationControlData('_languageCd', [ data['_languageCd'] ]),
	                       new tizen.ApplicationControlData('_itemId', [ data['_itemId'] ]),
	                       new tizen.ApplicationControlData('_itemGroupId',[ data['_itemGroupId'] ]),
	                       new tizen.ApplicationControlData('_transactionId',[ data['_transactionId'] ]),
	                       new tizen.ApplicationControlData('_indCarrierMode', [data['_indCarrierMode'] ])
	                       ];

	iap.SendAppControl('http://tizen.org/appcontrol/operation/iapv2/purchase', appIdClient, pAppControlData, iap.AppControlReplyCB);
};

iap.OnPurchaseItemReceived = function(data) {
	iap.listener.OnPurchaseItemReceived(data._result, data);
};

iap.RequestPurchasedItemInformationList = function(data) {
	var pAppControlData = [
	                       new tizen.ApplicationControlData('_transactionId',[ data['_transactionId'] ]),
	                       new tizen.ApplicationControlData('_startNumber',[ data['_startNumber'] ]),
	                       new tizen.ApplicationControlData('_endNumber',[ data['_endNumber'] ]),
	                       new tizen.ApplicationControlData('_itemGroupId',[ data['_itemGroupId'] ]),
	                       new tizen.ApplicationControlData('_mcc', [ data['_mcc'] ]),
	                       new tizen.ApplicationControlData('_mnc', [ data['_mnc'] ]),
	                       new tizen.ApplicationControlData('_mode', [ data['_mode'] ]),
	                       new tizen.ApplicationControlData('_languageCd', [ data['_languageCd'] ]),
	                       new tizen.ApplicationControlData('_startDate', [ data['_startDate'] ]),
	                       new tizen.ApplicationControlData('_endDate', [ data['_endDate'] ])
	                       ];
	iap.SendAppControl('http://tizen.org/appcontrol/operation/iapv2/get_purchased_item_list', appIdService, pAppControlData, iap.AppControlReplyCB);
};

iap.OnPurchasedItemInformationListReceived = function(data) {
	iap.listener.OnPurchasedItemInformationListReceived(data._result, data);
};

$(document).ready(function() {
	// Default Mode : Normal
	fn_allClear();
	
	iap.RegisterCallback(IapListener);
	
	// Get Country List
//	fn_getCountryList();
});

$(window).on("tizenhwkey", function(ev) {
   if (ev.originalEvent.keyName === "back") {
      tizen.application.getCurrentApplication().exit();
   }
});