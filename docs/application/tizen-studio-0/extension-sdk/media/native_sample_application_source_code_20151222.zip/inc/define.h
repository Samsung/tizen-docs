/*
 * Copyright (c) 2014 Samsung Electronics Co., Ltd All Rights Reserved
 *
 * Licensed under the Apache License, Version 2.0 (the License);
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an AS IS BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __DEFINE_H__
#define __DEFINE_H__

#include <Elementary.h>
#include <stdbool.h>

#define KEY_END "XF86Stop"

#if !defined(PACKAGE)
#define PACKAGE "org.tizen.iapsample"
#endif

#define MODE_NORMAL "0"
#define MODE_DEVELOPER "1"

/* IAP App Request parameter */
#define PARAM_REQUEST_MODE 				"_mode"
#define PARAM_REQUEST_TRANSACTION_ID		"_transactionId"
#define PARAM_REQUEST_START_NUMBER			"_startNumber"
#define PARAM_REQUEST_END_NUMBER			"_endNumber"
#define PARAM_REQUEST_ITEM_GROUP_ID		"_itemGroupId"
#define PARAM_REQUEST_LANGUAGE_CD			"_languageCd"
#define PARAM_REQUEST_ITEM_TYPE_CD			"_itemTypeCd"
#define PARAM_REQUEST_MCC					"_mcc"
#define PARAM_REQUEST_MNC					"_mnc"
#define PARAM_REQUEST_START_DATE 			"_startDate"
#define PARAM_REQUEST_END_DATE 			"_endDate"
#define PARAM_REQUEST_ITEM_ID	 			"_itemId"
#define PARAM_REQUEST_ITEM_NAME 			"_itemName"
#define PARAM_REQUEST_IND_CARRIER_MODE 	"_indCarrierMode"

/* IAP App Response parameter */
#define PARAM_RESPONSE_METHOD 				"_method"
#define PARAM_RESPONSE_RESULT 				"_result"
#define PARAM_RESPONSE_RESULT_DESCRIPTION 	"_resultDescription"
#define PARAM_RESPONSE_TRANSACTION_ID 		"_transactionId"
#define PARAM_RESPONSE_START_NUMBER 		"_startNumber"
#define PARAM_RESPONSE_END_NUMBER 			"_endNumber"
#define PARAM_RESPONSE_TOTAL_COUNT 		"_totalCount"
#define PARAM_RESPONSE_COUNTRY_NAME 		"_countryName"
#define PARAM_RESPONSE_MCC 				"_mcc"
#define PARAM_RESPONSE_ITEM_TOTAL_COUNT 	"_itemTotalCount"
#define PARAM_RESPONSE_ITEM_ID 			"_itemId"
#define PARAM_RESPONSE_ITEM_GROUP_ID 		"_itemGroupId"
#define PARAM_RESPONSE_ITEM_NAME 			"_itemName"
#define PARAM_RESPONSE_CURRENCY_UNIT 		"_currencyUnit"
#define PARAM_RESPONSE_UNIT_PRECEDES 		"_unitPrecedes"
#define PARAM_RESPONSE_HAS_PENNY 			"_hasPenny"
#define PARAM_RESPONSE_ITEM_PRICE 			"_itemPrice"
#define PARAM_RESPONSE_ITEM_DISCOUNT_FLAG 	"_itemDiscountFlag"
#define PARAM_RESPONSE_ITEM_REDUCED_PRICE 	"_itemReducedPrice"
#define PARAM_RESPONSE_ITEM_DOWNLOAD_URL 	"_itemDownloadUrl"
#define PARAM_RESPONSE_ITEM_IMAGE_URL 		"_itemImageUrl"
#define PARAM_RESPONSE_ITEM_DESCRIPTION 	"_itemDescription"
#define PARAM_RESPONSE_RESERVED1 			"_reserved1"
#define PARAM_RESPONSE_RESERVED2 			"_reserved2"
#define PARAM_RESPONSE_ITEM_TYPE_CD 		"_itemTypeCd"
#define PARAM_RESPONSE_ITEM_SUBS_BILL_DURATION_CD 			"_itemSubsBillDurationCd"
#define PARAM_RESPONSE_SUBSCRIPTION_DURATION_MULTIPLIER 	"_subscriptionDurationMultiplier"
#define PARAM_RESPONSE_TIME_STAMP 			"_timeStamp"
#define PARAM_RESPONSE_PAYMENT_ID 			"_paymentId"
#define PARAM_RESPONSE_PURCHASE_DATE 		"_purchaseDate"
#define PARAM_RESPONSE_TICKET_PURCHASE_ID	"_ticketPurchaseId"
#define PARAM_RESPONSE_TICKET_VERIFY_URL	"_ticketVerifyUrl"
#define PARAM_RESPONSE_TICKET_PARAM_1		"_ticketParam1"
#define PARAM_RESPONSE_TICKET_PARAM_2		"_ticketParam2"
#define PARAM_RESPONSE_TICKET_PARAM_3		"_ticketParam3"
#define PARAM_RESPONSE_TICKET_PARAM_4		"_ticketParam4"
#define PARAM_RESPONSE_TICKET_PARAM_5		"_ticketParam5"


#define DEFINE_DEV_ITEM_GROUP_ID "100000000001"
#define DEFINE_DEV_ITEM_TYPE_CODE "10"
#define DEFINE_DEV_LANGUAGE_CODE "ENG"
#define DEFINE_DEV_MNC "01"
#define DEFINE_DEV_START_DATE "2014-01-01"
#define DEFINE_DEV_END_DATE "2020-12-31"

#define DEFINE_PRD_ITEM_GROUP_ID "100000068125"	//PRD
//#define DEFINE_PRD_ITEM_GROUP_ID "100000062106"	//PRD
//#define DEFINE_PRD_ITEM_GROUP_ID "100000068125"	//PRD
//#define DEFINE_PRD_ITEM_GROUP_ID "100000031005"	//STG - SM-Z130E
//#define DEFINE_PRD_ITEM_GROUP_ID "100000018005"	//DEV
#define DEFINE_PRD_ITEM_TYPE_CODE "10"
#define DEFINE_PRD_LANGUAGE_CODE "ENG"
#define DEFINE_PRD_MNC "01"
#define DEFINE_PRD_START_DATE "2014-01-01"
#define DEFINE_PRD_END_DATE "2020-12-31"

#define IAP_SEARCH_OPTION_MCC "mcc"
#define IAP_SEARCH_OPTION_MNC "mnc"
#define IAP_SEARCH_OPTION_ITEM_GROUP_ID "item_group_id"
#define IAP_SEARCH_OPTION_ITEM_TYPE_CODE "item_type_code"

/* APP_ID */
#ifndef _NEW_APP_ID
#define _NEW_APP_ID
#endif

#ifdef _NEW_APP_ID
#define IAP_SERVICE_APP_ID "tizeninapp.IapService"  // org.tizen.inapppurchase.iapservice
#define IAP_CLIENT_APP_ID "org.tizen.inapppurchase.iapclient" // org.tizen.inapppurchase.iapclient
#else
#define IAP_SERVICE_APP_ID "tizeninapp.iapservice"
#define IAP_CLIENT_APP_ID "tizeninapp.iapclient"
#endif

/* IAP Operation */
#define OPERATION_GET_COUNTRY_LIST "http://tizen.org/appcontrol/operation/iapv2/get_country_list"
#define OPERATION_GET_ITEM_LIST "http://tizen.org/appcontrol/operation/iapv2/get_item_list"
#define OPERATION_GET_PURCHASED_ITEM_LIST "http://tizen.org/appcontrol/operation/iapv2/get_purchased_item_list"
#define OPERATION_PURCHASE "http://tizen.org/appcontrol/operation/iapv2/purchase"


/* Item type */
#define ITEM_TYPE_CODE_NON_CONSUMABLE "00"
#define ITEM_TYPE_CODE_CONSUMABLE "01"
#define ITEM_TYPE_CODE_SUBSCRIPTION "02"
#define ITEM_TYPE_CODE_ALL "10"
#define ITEM_TYPE_NAME_NON_CONSUMABLE "Non-consumable"
#define ITEM_TYPE_NAME_CONSUMABLE "Consumable"
#define ITEM_TYPE_NAME_SUBSCRIPTION "Subscription"
#define ITEM_TYPE_NAME_ALL "All"

/* currency sign position*/
#define UNIT_PRECEDES_RIGHT "0"
#define UNIT_PRECEDES_LEFT "1"

/* result */
#define RESULT_SUCCESS "0"

#define RESULT_ERROR_200 "200"		//NetworkError
#define RESULT_ERROR_2001 "2001"	//NoApplicationStore
#define RESULT_ERROR_1000 "1000"	//ProcessError
#define RESULT_ERROR_9201 "9201"	//ItemGroupIdNotFound
#define RESULT_ERROR_9207 "9207"	//ItemIdNotFound
#define RESULT_ERROR_9502 "9502"	//InvalidRequestParam
#define RESULT_ERROR_100 "100"		//UserCancel
#define RESULT_ERROR_5600 "5600"	//PGError
#define RESULT_ERROR_9291 "9291"	//No Reorder Item
#define RESULT_ERROR_9292 "9292"	//Update is Progressing


#define NUM_OF_ITEMS 50

#define TIZEN_ICON "/opt/usr/apps/"PACKAGE"/res/images/tizen.png"

#define MM_FREE(p) if(p)free(p); p=(void *)0 // g_memory_count--;

#define IAP_REQUEST_TIME_OUT 60

typedef enum {
	FUNC_GET_COUNTRY_LIST = 1,
	FUNC_GET_ITEM_LIST = 2,
	FUNC_GET_PURCHASED_ITEM_LIST = 3,
	FUNC_PURCHASE = 4
} iap_menu_e;

typedef struct request_parameter{
	char mode[2];
	int transaction_id;
	int start_number;
	int end_number;
	char start_date[12];
	char end_date[12];
	char item_id[16];
	char item_name[256];
	char item_group_id[16];
	char language_cd[8];
	char item_type_cd[4];
	char mcc[8];
	char mnc[8];
}request_param_s;

typedef struct country {
	char name[100];
	char mcc[8];
} country_s;

typedef struct country_list {
	char method[128];
	char result[16];
	char result_description[256];
	char transaction_id[16];
	int start_number;
	int end_number;
	int total_count;
	country_s *items[NUM_OF_ITEMS];

	int item_size;
} country_list_s;


typedef struct item {
	char item_id[16];
	char item_group_id[16];
	char item_name[256];
	char currency_unit[8];
	char unit_precedes[4];
	char has_penny[4];
	char item_price[16];
	char item_download_url[256];
	char item_image_url[256];
	char item_description[1024];
	char reserved1[256];
	char reserved2[256];
	char payment_id[32];
	char purchase_date[32];
	char item_type_cd[4];
	char item_subs_bill_duration_cd[4];
	char subscription_duration_multiplier[4];
	char time_stamp[16];
	int is_purchased;
	char item_image_path[256];
	char item_discount_flag[4];
	char item_reduced_price[16];

	Elm_Object_Item *elm_item;
} item_s;

typedef struct item_list {
	char method[128];
	char result[16];
	char result_description[256];
	char transaction_id[16];
	int start_number;
	int end_number;
	int total_count;
	int item_total_count;

	item_s *items[NUM_OF_ITEMS];
	int item_size;
} item_list_s;

typedef struct purchase {
	char method[128];
	char result[16];
	char result_description[256];
	char item_id[16];
	char item_group_id[16];
	char item_name[256];
	char currency_unit[8];
	char unit_precedes[4];
	char has_penny[4];
	char item_price[16];
	char item_download_url[256];
	char item_image_url[256];
	char item_description[1024];
	char reserved1[256];
	char reserved2[256];
	char payment_id[128];
	char ticket_purchase_id[128];
	char ticket_verify_url[512];
	char ticket_param1[128];
	char ticket_param2[128];
	char ticket_param3[128];
	char ticket_param4[128];
	char ticket_param5[128];
	char purchase_date[32];
	char item_type_cd[4];
	char item_subs_bill_duration_cd[4];
	char sub_scription_duration_multiplier[8];
	char time_stamp[32];
	char item_discount_flag[4];
	char item_reduced_price[16];
} purchase_s;

typedef struct appdata {
	Evas_Object *win;
	Evas_Object *label;
	Evas_Object *conform;
	Evas_Object *nf;
	Evas_Object *layout;
	Evas_Object *popup;
	Evas_Object *popup_ef;
	Evas_Object *box;
	Evas_Object *genlist;
	Evas_Object *loading_popup;

	bool is_popup_show;

	int mode;

	Ecore_Timer *timer;
	bool is_popup_main_loop;

} appdata_s;


typedef struct control_object {
	Evas_Object *mode;
	Evas_Object *mcc;
	Evas_Object *mnc;
	Evas_Object *item_group_id;
	Evas_Object *item_type_code;
} control_object_s;

typedef struct search_config {
	char mode[4];
	char item_group_id[16];
	char item_type_code[4];
	char language_code[8];
	char mcc[8];
	char mnc[8];
	char start_date[16];
	char end_date[16];
} search_config_s;


typedef struct item_type {
	char name[30];
	char value[4];
	int id;
} item_type_s;


typedef struct iap_result {
	country_list_s *country_list_result;
	item_list_s *item_list_result;
	purchase_s *purchase_result;
} iap_result_s;
appdata_s *ad;
control_object_s *control_object;
search_config_s *search_config;
Eina_Hash *hash_country;
item_type_s *item_types[4];
iap_result_s *iap_result;


#endif
