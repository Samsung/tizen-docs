/*
 * Copyright (c) 2014 Samsung Electronics Co., Ltd All Rights Reserved
 *
 * Licensed under the Apache License, Version 2.0 (the License);
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an AS IS BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


#ifndef __COMMON_H__
#define __COMMON_H__


int init_control_object();

int init_configuration();

int free_configuration();

void init_country_hash();

void free_country_hash();

char* get_hash_from_mnc(const char* mcc);

int create_search_parameter(request_param_s* param);

void free_search_parameter(request_param_s* param);

void init_item_type();

void free_item_type();

void init_iap_result();

void free_iap_result(iap_menu_e menu);

char* get_iap_result_message(const char* result_code);

int get_iap_resolution();

#endif
