/*
 * Copyright (c) 2014 Samsung Electronics Co., Ltd All Rights Reserved
 *
 * Licensed under the Apache License, Version 2.0 (the License);
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an AS IS BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <app_control.h>

#include "dbg.h"
#include "define.h"
#include "common.h"
#include "form.h"
#include "popup.h"

static void
_get_country_list_cb(app_control_h request, app_control_h reply, app_control_result_e result, void *user_data);

static void
_get_item_list_cb(app_control_h request, app_control_h reply, app_control_result_e result, void *user_data);

static void
_get_purchased_item_list_cb(app_control_h request, app_control_h reply, app_control_result_e result, void *user_data);

static void
_get_purchase_cb(app_control_h request, app_control_h reply, app_control_result_e result, void *user_data);

static void
_get_country_list_operation_call(request_param_s *param);

static void
_get_item_list_operation_call(request_param_s *param);

static void
_get_purchased_item_list_operation_call(request_param_s *param);

static void
_purchase_operation_call(request_param_s *param);

static int
_make_transaction_id();

static void
_get_char_extra_data(app_control_h app_control, char *target, char *param_name, int num);

static void
_get_int_extra_data(app_control_h app_control, int *target, char *param_name, int num);

static void
_app_control_error_popup(int rt);


int
_make_transaction_id(){
	srand(time( NULL));
	return (rand() % 1000000 + 1);
}


/*
 * result call back for get_country_list
 */
void _get_country_list_cb(app_control_h request, app_control_h reply, app_control_result_e result, void *user_data)
{
	LOGI("[IAP_SAMPLE] _get_country_list_cb()");

	iap_popup_loading(false);

	country_list_s *list;
	country_s *country;
	list = (country_list_s *)malloc(sizeof(country_list_s));
	memset(list, 0X00, sizeof(country_list_s));

	if (result == APP_CONTROL_RESULT_SUCCEEDED){

		list->item_size = 0;

		_get_char_extra_data(reply, list->method, PARAM_RESPONSE_METHOD, -1);
		_get_char_extra_data(reply, list->result, PARAM_RESPONSE_RESULT, -1);
		_get_char_extra_data(reply, list->result_description, PARAM_RESPONSE_RESULT_DESCRIPTION, -1);
		_get_char_extra_data(reply, list->transaction_id, PARAM_RESPONSE_TRANSACTION_ID, -1);
		_get_int_extra_data(reply, &(list->start_number), PARAM_RESPONSE_START_NUMBER, -1);
		_get_int_extra_data(reply, &(list->end_number), PARAM_RESPONSE_END_NUMBER, -1);
		_get_int_extra_data(reply, &(list->total_count), PARAM_RESPONSE_TOTAL_COUNT, -1);

		if (list->start_number > 0 && list->end_number > 0){

			int index_start, j=0;
			for(index_start = list->start_number; index_start <= list->end_number; index_start++){
				country = (country_s *)malloc(sizeof(country_s));
				memset(country, 0X00, sizeof(country_s));

				_get_char_extra_data(reply, country->name, PARAM_RESPONSE_COUNTRY_NAME, index_start);
				_get_char_extra_data(reply, country->mcc, PARAM_RESPONSE_MCC, index_start);

				list->items[j] = country;
				j++;
			}
			list->item_size = j;
		}

		create_result_view(FUNC_GET_COUNTRY_LIST, list);
	} else {
		if (result == APP_CONTROL_RESULT_FAILED){
			iap_common_popup(ad->popup, "error", "Operation failed by the callee");
		} else if (result == APP_CONTROL_RESULT_CANCELED) {
			iap_common_popup(ad->popup, "error", "Operation canceled by the framework");
		} else {
			iap_common_popup(ad->popup, "error", "Unknown error");
		}
	}

	free_iap_result(FUNC_GET_COUNTRY_LIST);

	iap_result->country_list_result = list;
}

/*
 * result call back for get_item_list
 */
void _get_item_list_cb(app_control_h request, app_control_h reply, app_control_result_e result, void *user_data)
{
	LOGI("[IAP_SAMPLE] _get_item_list_cb()");

	iap_popup_loading(false);

	item_list_s *list;
	item_s *item;

	list = (item_list_s *)malloc(sizeof(item_list_s));
	memset(list, 0X00, sizeof(item_list_s));

	if (result == APP_CONTROL_RESULT_SUCCEEDED){

		list->item_size = 0;

		_get_char_extra_data(reply, list->method, PARAM_RESPONSE_METHOD, -1);
		_get_char_extra_data(reply, list->result, PARAM_RESPONSE_RESULT, -1);
		_get_char_extra_data(reply, list->result_description, PARAM_RESPONSE_RESULT_DESCRIPTION, -1);
		_get_char_extra_data(reply, list->transaction_id, PARAM_RESPONSE_TRANSACTION_ID, -1);
		_get_int_extra_data(reply, &(list->start_number), PARAM_RESPONSE_START_NUMBER, -1);
		_get_int_extra_data(reply, &(list->end_number), PARAM_RESPONSE_END_NUMBER, -1);
		_get_int_extra_data(reply, &(list->total_count), PARAM_RESPONSE_TOTAL_COUNT, -1);
		_get_int_extra_data(reply, &(list->item_total_count), PARAM_RESPONSE_ITEM_TOTAL_COUNT, -1);

		if (list->total_count > 0 && list->start_number > 0 && list->end_number > 0){

			int index_start, j=0;

			for(index_start = list->start_number; index_start <= list->end_number; index_start++){

				item = (item_s *)malloc(sizeof(item_s));
				memset(item, 0X00, sizeof(item_s));

				_get_char_extra_data(reply, item->item_id, PARAM_RESPONSE_ITEM_ID, index_start);
				_get_char_extra_data(reply, item->item_group_id, PARAM_RESPONSE_ITEM_GROUP_ID, index_start);
				_get_char_extra_data(reply, item->item_name, PARAM_RESPONSE_ITEM_NAME, index_start);
				_get_char_extra_data(reply, item->currency_unit, PARAM_RESPONSE_CURRENCY_UNIT, index_start);
				_get_char_extra_data(reply, item->unit_precedes, PARAM_RESPONSE_UNIT_PRECEDES, index_start);
				_get_char_extra_data(reply, item->has_penny, PARAM_RESPONSE_HAS_PENNY, index_start);
				_get_char_extra_data(reply, item->item_price, PARAM_RESPONSE_ITEM_PRICE, index_start);
				_get_char_extra_data(reply, item->item_download_url, PARAM_RESPONSE_ITEM_DOWNLOAD_URL, index_start);
				_get_char_extra_data(reply, item->item_image_url, PARAM_RESPONSE_ITEM_IMAGE_URL, index_start);
				_get_char_extra_data(reply, item->item_description, PARAM_RESPONSE_ITEM_DESCRIPTION, index_start);
				_get_char_extra_data(reply, item->reserved1, PARAM_RESPONSE_RESERVED1, index_start);
				_get_char_extra_data(reply, item->reserved2, PARAM_RESPONSE_RESERVED2, index_start);
				_get_char_extra_data(reply, item->item_type_cd, PARAM_RESPONSE_ITEM_TYPE_CD, index_start);
				_get_char_extra_data(reply, item->item_subs_bill_duration_cd, PARAM_RESPONSE_ITEM_SUBS_BILL_DURATION_CD, index_start);
				_get_char_extra_data(reply, item->subscription_duration_multiplier, PARAM_RESPONSE_SUBSCRIPTION_DURATION_MULTIPLIER, index_start);
				_get_char_extra_data(reply, item->time_stamp, PARAM_RESPONSE_TIME_STAMP, index_start);
				_get_char_extra_data(reply, item->item_discount_flag, PARAM_RESPONSE_ITEM_DISCOUNT_FLAG, index_start);
				_get_char_extra_data(reply, item->item_reduced_price, PARAM_RESPONSE_ITEM_REDUCED_PRICE, index_start);


				list->items[j] = item;
				j++;
			}
			list->item_size = j;
		}

		create_result_view(FUNC_GET_ITEM_LIST, list);
	} else {
		if (result == APP_CONTROL_RESULT_FAILED){
			iap_common_popup(ad->popup, "error", "Operation failed by the callee");
		} else if (result == APP_CONTROL_RESULT_CANCELED) {
			iap_common_popup(ad->popup, "error", "Operation canceled by the framework");
		} else {
			iap_common_popup(ad->popup, "error", "Unknown error");
		}
	}

	free_iap_result(FUNC_GET_ITEM_LIST);

	iap_result->item_list_result = list;
}

/*
 * result call back for get_purchased_item_list
 */
void _get_purchased_item_list_cb(app_control_h request, app_control_h reply, app_control_result_e result, void *user_data)
{
	LOGI("[IAP_SAMPLE] _get_purchased_item_list_cb()");

	iap_popup_loading(false);

	item_list_s *list;
	item_s *item;

	list = (item_list_s *)malloc(sizeof(item_list_s));
	memset(list, 0X00, sizeof(item_list_s));

	if (result == APP_CONTROL_RESULT_SUCCEEDED){

		list->item_size = 0;
		_get_char_extra_data(reply, list->method, PARAM_RESPONSE_METHOD, -1);
		_get_char_extra_data(reply, list->result, PARAM_RESPONSE_RESULT, -1);
		_get_char_extra_data(reply, list->result_description, PARAM_RESPONSE_RESULT_DESCRIPTION, -1);
		_get_char_extra_data(reply, list->transaction_id, PARAM_RESPONSE_TRANSACTION_ID, -1);
		_get_int_extra_data(reply, &(list->start_number), PARAM_RESPONSE_START_NUMBER, -1);
		_get_int_extra_data(reply, &(list->end_number), PARAM_RESPONSE_END_NUMBER, -1);
		_get_int_extra_data(reply, &(list->total_count), PARAM_RESPONSE_TOTAL_COUNT, -1);
		_get_int_extra_data(reply, &(list->item_total_count), PARAM_RESPONSE_ITEM_TOTAL_COUNT, -1);

		if (list->total_count > 0 && list->start_number > 0 && list->end_number > 0){

			int index_start, j=0;

			for(index_start = list->start_number; index_start <= list->end_number; index_start++){

				item = (item_s *)malloc(sizeof(item_s));
				memset(item, 0X00, sizeof(item_s));

				_get_char_extra_data(reply, item->item_id, PARAM_RESPONSE_ITEM_ID, index_start);
				_get_char_extra_data(reply, item->item_group_id, PARAM_RESPONSE_ITEM_GROUP_ID, index_start);
				_get_char_extra_data(reply, item->item_name, PARAM_RESPONSE_ITEM_NAME, index_start);
				_get_char_extra_data(reply, item->currency_unit, PARAM_RESPONSE_CURRENCY_UNIT, index_start);
				_get_char_extra_data(reply, item->unit_precedes, PARAM_RESPONSE_UNIT_PRECEDES, index_start);
				_get_char_extra_data(reply, item->has_penny, PARAM_RESPONSE_HAS_PENNY, index_start);
				_get_char_extra_data(reply, item->item_price, PARAM_RESPONSE_ITEM_PRICE, index_start);
				_get_char_extra_data(reply, item->item_download_url, PARAM_RESPONSE_ITEM_DOWNLOAD_URL, index_start);
				_get_char_extra_data(reply, item->item_image_url, PARAM_RESPONSE_ITEM_IMAGE_URL, index_start);
				_get_char_extra_data(reply, item->item_description, PARAM_RESPONSE_ITEM_DESCRIPTION, index_start);
				_get_char_extra_data(reply, item->reserved1, PARAM_RESPONSE_RESERVED1, index_start);
				_get_char_extra_data(reply, item->reserved2, PARAM_RESPONSE_RESERVED2, index_start);
				_get_char_extra_data(reply, item->payment_id, PARAM_RESPONSE_PAYMENT_ID, index_start);
				_get_char_extra_data(reply, item->purchase_date, PARAM_RESPONSE_PURCHASE_DATE, index_start);
				_get_char_extra_data(reply, item->item_type_cd, PARAM_RESPONSE_ITEM_TYPE_CD, index_start);
				_get_char_extra_data(reply, item->item_subs_bill_duration_cd, PARAM_RESPONSE_ITEM_SUBS_BILL_DURATION_CD, index_start);
				_get_char_extra_data(reply, item->subscription_duration_multiplier, PARAM_RESPONSE_SUBSCRIPTION_DURATION_MULTIPLIER, index_start);
				_get_char_extra_data(reply, item->time_stamp, PARAM_RESPONSE_TIME_STAMP, index_start);
				_get_char_extra_data(reply, item->item_discount_flag, PARAM_RESPONSE_ITEM_DISCOUNT_FLAG, index_start);
				_get_char_extra_data(reply, item->item_reduced_price, PARAM_RESPONSE_ITEM_REDUCED_PRICE, index_start);

				list->items[j] = item;
				j++;
			}
			list->item_size = j;
		}

		create_result_view(FUNC_GET_PURCHASED_ITEM_LIST, list);
	} else {
		if (result == APP_CONTROL_RESULT_FAILED){
			iap_common_popup(ad->popup, "error", "Operation failed by the callee");
		} else if (result == APP_CONTROL_RESULT_CANCELED) {
			iap_common_popup(ad->popup, "error", "Operation canceled by the framework");
		} else {
			iap_common_popup(ad->popup, "error", "Unknown error");
		}
	}

	free_iap_result(FUNC_GET_PURCHASED_ITEM_LIST);

	iap_result->item_list_result = list;
}

/*
 * result call back for purchase
 */
void _get_purchase_cb(app_control_h request, app_control_h reply, app_control_result_e result, void *user_data)
{
	LOGI("[IAP_SAMPLE] _get_purchase_cb()");
	_INFO("purchase result callback result:%d", result);

	purchase_s *purchase;
	purchase = (purchase_s *)malloc(sizeof(purchase_s));
	memset(purchase, 0X00, sizeof(purchase_s));

	if (result == APP_CONTROL_RESULT_SUCCEEDED){

		_get_char_extra_data(reply, purchase->method, PARAM_RESPONSE_METHOD, -1);
		_get_char_extra_data(reply, purchase->result, PARAM_RESPONSE_RESULT, -1);
		_get_char_extra_data(reply, purchase->result_description, PARAM_RESPONSE_RESULT_DESCRIPTION, -1);
		_get_char_extra_data(reply, purchase->item_id, PARAM_RESPONSE_ITEM_ID, -1);
		_get_char_extra_data(reply, purchase->item_group_id, PARAM_RESPONSE_ITEM_GROUP_ID, -1);
		_get_char_extra_data(reply, purchase->item_name, PARAM_RESPONSE_ITEM_NAME, -1);
		_get_char_extra_data(reply, purchase->ticket_purchase_id, PARAM_RESPONSE_TICKET_PURCHASE_ID, -1);
		_get_char_extra_data(reply, purchase->currency_unit, PARAM_RESPONSE_CURRENCY_UNIT, -1);
		_get_char_extra_data(reply, purchase->unit_precedes, PARAM_RESPONSE_UNIT_PRECEDES, -1);
		_get_char_extra_data(reply, purchase->has_penny, PARAM_RESPONSE_HAS_PENNY, -1);
		_get_char_extra_data(reply, purchase->item_price, PARAM_RESPONSE_ITEM_PRICE, -1);
		_get_char_extra_data(reply, purchase->item_download_url, PARAM_RESPONSE_ITEM_DOWNLOAD_URL, -1);
		_get_char_extra_data(reply, purchase->item_image_url, PARAM_RESPONSE_ITEM_IMAGE_URL, -1);
		_get_char_extra_data(reply, purchase->item_description, PARAM_RESPONSE_ITEM_DESCRIPTION, -1);
		_get_char_extra_data(reply, purchase->reserved1, PARAM_RESPONSE_RESERVED1, -1);
		_get_char_extra_data(reply, purchase->reserved2, PARAM_RESPONSE_RESERVED2, -1);
		_get_char_extra_data(reply, purchase->payment_id, PARAM_RESPONSE_PAYMENT_ID, -1);
		_get_char_extra_data(reply, purchase->ticket_verify_url, PARAM_RESPONSE_TICKET_VERIFY_URL, -1);
		_get_char_extra_data(reply, purchase->ticket_purchase_id, PARAM_RESPONSE_TICKET_PURCHASE_ID, -1);
		_get_char_extra_data(reply, purchase->ticket_param1, PARAM_RESPONSE_TICKET_PARAM_1, -1);
		_get_char_extra_data(reply, purchase->ticket_param2, PARAM_RESPONSE_TICKET_PARAM_2, -1);
		_get_char_extra_data(reply, purchase->ticket_param3, PARAM_RESPONSE_TICKET_PARAM_3, -1);
		_get_char_extra_data(reply, purchase->ticket_param4, PARAM_RESPONSE_TICKET_PARAM_4, -1);
		_get_char_extra_data(reply, purchase->ticket_param5, PARAM_RESPONSE_TICKET_PARAM_5, -1);
		_get_char_extra_data(reply, purchase->purchase_date, PARAM_RESPONSE_PURCHASE_DATE, -1);
		_get_char_extra_data(reply, purchase->item_type_cd, PARAM_RESPONSE_ITEM_TYPE_CD, -1);
		_get_char_extra_data(reply, purchase->item_subs_bill_duration_cd, PARAM_RESPONSE_ITEM_SUBS_BILL_DURATION_CD, -1);
		_get_char_extra_data(reply, purchase->sub_scription_duration_multiplier, PARAM_RESPONSE_SUBSCRIPTION_DURATION_MULTIPLIER, -1);
		_get_char_extra_data(reply, purchase->time_stamp, PARAM_RESPONSE_TIME_STAMP, -1);
		_get_char_extra_data(reply, purchase->item_discount_flag, PARAM_RESPONSE_ITEM_DISCOUNT_FLAG, -1);
		_get_char_extra_data(reply, purchase->item_reduced_price, PARAM_RESPONSE_ITEM_REDUCED_PRICE, -1);

		create_result_view(FUNC_PURCHASE, purchase);
	} else {
		if (result == APP_CONTROL_RESULT_FAILED){
			iap_common_popup(ad->popup, "error", "Operation failed by the callee");
		} else if (result == APP_CONTROL_RESULT_CANCELED) {
			iap_common_popup(ad->popup, "error", "Operation canceled by the framework");
		} else {
			iap_common_popup(ad->popup, "error", "Unknown error");
		}
	}

	free_iap_result(FUNC_PURCHASE);

	iap_result->purchase_result = purchase;
}

/*
 * result call back for get_country_list
 */
void _get_country_list_operation_call(request_param_s *param)
{
	LOGI("[IAP_SAMPLE] _get_country_list_operation_call()");
	app_control_h app_control;

	int rt = app_control_create(&app_control);
	LOGI("[IAP_SAMPLE] app_control_create -> %d",rt);

	if (rt == APP_CONTROL_ERROR_NONE){
		if (param){
			char buffer[1024] = {0,};
			snprintf(buffer, sizeof(buffer), "%d", param->transaction_id);
#if 1
			app_control_set_app_id(app_control, IAP_SERVICE_APP_ID);
#else
			app_control_set_app_id(app_control, "org.tizen.inapppurchase.iapservice");
#endif
			app_control_set_operation(app_control, OPERATION_GET_COUNTRY_LIST);
			app_control_add_extra_data(app_control, PARAM_REQUEST_TRANSACTION_ID, buffer);

			rt = app_control_send_launch_request(app_control, _get_country_list_cb, param);
			LOGI("[IAP_SAMPLE] app_control_send_launch_request -> %d",rt);

//			LOGI("[IAP_SAMPLE] 0x21 -> %d",TIZEN_ERROR_APPLICATION | 0x21);
//			LOGI("[IAP_SAMPLE] 0x22 -> %d",TIZEN_ERROR_APPLICATION | 0x22);
//			LOGI("[IAP_SAMPLE] 0x23 -> %d",TIZEN_ERROR_APPLICATION | 0x23);
//			LOGI("[IAP_SAMPLE] 0x24 -> %d",TIZEN_ERROR_APPLICATION | 0x24);

			_app_control_error_popup(rt);

			if (rt == APP_CONTROL_ERROR_NONE ){
				iap_popup_loading(true);
			}

		} else {
			iap_common_popup(ad->popup, "error", "Request parameter error");
		}
	} else {
		_app_control_error_popup(rt);
	}
	if (app_control != NULL){
		app_control_destroy(app_control);
	}
	free_search_parameter(param);
}


/**
 * get_item_list 요청
 * <pre>
 * 이 메소드는 AppControl을 통해 get_item_list를 요청하기 위한 함수이다.
 * app_control_create를 이용해 appControl을 생성 후 요청할 App ID와 Operation을 셋팅한다
 * 요청할 규격의 파라메터는 app_control_add_extra_data() 를 통해 설정한다
 * </pre>
 *
 * @param param : 요청할 파라메터정보를 담은 구조체
 */
void _get_item_list_operation_call(request_param_s *param)
{
	LOGI("[IAP_SAMPLE] _get_item_list_operation_call()");

	app_control_h app_control;
	int rt = app_control_create(&app_control);

	if (rt == APP_CONTROL_ERROR_NONE){

		if (param != NULL){
			param->transaction_id = _make_transaction_id();

			char buffer[1024] = {0,};

			_DBG(">>>>>>> IAP_SERVICE_APP_ID : %s", IAP_SERVICE_APP_ID);

			app_control_set_app_id(app_control, IAP_SERVICE_APP_ID);
			app_control_set_operation(app_control, OPERATION_GET_ITEM_LIST);
			app_control_add_extra_data(app_control, PARAM_REQUEST_MODE, param->mode);
			memset(buffer, 0X00, sizeof(buffer));
			snprintf(buffer, sizeof(buffer), "%d", param->transaction_id);
			app_control_add_extra_data(app_control, PARAM_REQUEST_TRANSACTION_ID, buffer);
			memset(buffer, 0X00, sizeof(buffer));
			snprintf(buffer, sizeof(buffer), "%d", param->start_number);
			app_control_add_extra_data(app_control, PARAM_REQUEST_START_NUMBER, buffer);
			memset(buffer, 0X00, sizeof(buffer));
			snprintf(buffer, sizeof(buffer), "%d", param->end_number);
			app_control_add_extra_data(app_control, PARAM_REQUEST_END_NUMBER, buffer);
			app_control_add_extra_data(app_control, PARAM_REQUEST_ITEM_GROUP_ID, param->item_group_id);
			app_control_add_extra_data(app_control, PARAM_REQUEST_LANGUAGE_CD, param->language_cd);
			app_control_add_extra_data(app_control, PARAM_REQUEST_ITEM_TYPE_CD, param->item_type_cd);

			if (param->mcc != NULL){
				app_control_add_extra_data(app_control, PARAM_REQUEST_MCC, param->mcc);
			}
			if (param->mnc != NULL){
				app_control_add_extra_data(app_control, PARAM_REQUEST_MNC, param->mnc);
			}

			rt = app_control_send_launch_request(app_control, _get_item_list_cb, param);

			_app_control_error_popup(rt);

			if (rt == APP_CONTROL_ERROR_NONE ){
				iap_popup_loading(true);
			}
		} else {
			_ERR("request parameter error");
		}
	} else {
		_app_control_error_popup(rt);
	}
	if (app_control != NULL){
		app_control_destroy(app_control);
	}

	free_search_parameter(param);
}

/**
 * get_purchased_item_list 요청
 * <pre>
 * 이 메소드는 AppControl을 통해 get_purchased_item_list를 요청하기 위한 함수이다.
 * app_control_create를 이용해 appControl을 생성 후 요청할 App ID와 Operation을 셋팅한다
 * 요청할 규격의 파라메터는 app_control_add_extra_data() 를 통해 설정한다
 * </pre>
 *
 * @param param : 요청할 파라메터정보를 담은 구조체
 */
void _get_purchased_item_list_operation_call(request_param_s *param)
{
	LOGI("[IAP_SAMPLE] _get_purchased_item_list_operation_call()");

	app_control_h app_control;
	int rt = app_control_create(&app_control);

	if (rt == APP_CONTROL_ERROR_NONE){
		if (param){
			param->transaction_id = _make_transaction_id();

			char buffer[1024] = {0,};

			app_control_set_app_id(app_control, IAP_SERVICE_APP_ID);
			app_control_set_operation(app_control, OPERATION_GET_PURCHASED_ITEM_LIST);

			app_control_add_extra_data(app_control, PARAM_REQUEST_MODE, param->mode);

			memset(buffer, 0X00, sizeof(buffer));
			snprintf(buffer, sizeof(buffer), "%d", param->transaction_id);
			app_control_add_extra_data(app_control, PARAM_REQUEST_TRANSACTION_ID, buffer);

			memset(buffer, 0X00, sizeof(buffer));
			snprintf(buffer, sizeof(buffer), "%d", param->start_number);
			app_control_add_extra_data(app_control, PARAM_REQUEST_START_NUMBER, buffer);

			memset(buffer, 0X00, sizeof(buffer));
			snprintf(buffer, sizeof(buffer), "%d", param->end_number);
			app_control_add_extra_data(app_control, PARAM_REQUEST_END_NUMBER, buffer);

			app_control_add_extra_data(app_control, PARAM_REQUEST_START_DATE, param->start_date);
			app_control_add_extra_data(app_control, PARAM_REQUEST_END_DATE, param->end_date);
			app_control_add_extra_data(app_control, PARAM_REQUEST_ITEM_GROUP_ID, param->item_group_id);
			app_control_add_extra_data(app_control, PARAM_REQUEST_LANGUAGE_CD, param->language_cd);

			if (param->mcc != NULL){
				app_control_add_extra_data(app_control, PARAM_REQUEST_MCC, param->mcc);
			}
			if (param->mnc != NULL){
				app_control_add_extra_data(app_control, PARAM_REQUEST_MNC, param->mnc);
			}

			rt = app_control_send_launch_request(app_control, _get_purchased_item_list_cb, param);

			_app_control_error_popup(rt);

			if (rt == APP_CONTROL_ERROR_NONE ){
				iap_popup_loading(true);
			}

		} else {
			_ERR("request parameter error");
		}
	} else {
		_app_control_error_popup(rt);
	}
	if (app_control != NULL){
		app_control_destroy(app_control);
	}
	free_search_parameter(param);
}

/*
 * request purchase
 */
void _purchase_operation_call(request_param_s *param)
{
	LOGI("[IAP_SAMPLE] _purchase_operation_call()");

	app_control_h app_control;
	int rt = app_control_create(&app_control);

	if (rt == APP_CONTROL_ERROR_NONE){
		if (param){
			char buffer[1024] = {0,};

			param->transaction_id = _make_transaction_id();
			app_control_set_app_id(app_control, IAP_CLIENT_APP_ID);
			app_control_set_operation(app_control, OPERATION_PURCHASE);

			app_control_add_extra_data(app_control, PARAM_REQUEST_MODE, param->mode);

			memset(buffer, 0X00, sizeof(buffer));
			snprintf(buffer, sizeof(buffer), "%d", param->transaction_id);
			app_control_add_extra_data(app_control, PARAM_REQUEST_TRANSACTION_ID, buffer);

			app_control_add_extra_data(app_control, PARAM_REQUEST_ITEM_ID, param->item_id);
			app_control_add_extra_data(app_control, PARAM_REQUEST_ITEM_GROUP_ID, param->item_group_id);
			app_control_add_extra_data(app_control, PARAM_REQUEST_LANGUAGE_CD, param->language_cd);

			if (!strcmp("1", param->mode)){
				app_control_add_extra_data(app_control, PARAM_REQUEST_IND_CARRIER_MODE, "1");
			} else {
				app_control_add_extra_data(app_control, PARAM_REQUEST_IND_CARRIER_MODE, "0");
			}

			_DBG("%s = %s", PARAM_REQUEST_ITEM_ID, param->item_id);
			_DBG("%s = %s", PARAM_REQUEST_ITEM_GROUP_ID, param->item_group_id);
			_DBG("%s = %s", PARAM_REQUEST_LANGUAGE_CD, param->language_cd);
			_DBG("%s = %s", PARAM_REQUEST_ITEM_NAME, param->item_name);


			if (param->mcc != NULL){
				app_control_add_extra_data(app_control, PARAM_REQUEST_MCC, param->mcc);
			}
			if (param->mnc != NULL){
				app_control_add_extra_data(app_control, PARAM_REQUEST_MNC, param->mnc);
			}

			rt = app_control_send_launch_request(app_control, _get_purchase_cb, param);

			_app_control_error_popup(rt);

		} else {
			_ERR("request parameter error");
		}
	} else {
		_app_control_error_popup(rt);
	}
	if (app_control != NULL){
		app_control_destroy(app_control);
	}
	free_search_parameter(param);
}


void _get_char_extra_data(app_control_h app_control, char *target, char *param_name, int num)
{
	LOGI("[IAP_SAMPLE] _get_char_extra_data()");

	char *data = NULL;
	int rt;
	char buf[100] = {0,};

	if (num >= 0){
		snprintf(buf, sizeof(buf), "%d%s", num, param_name);
	} else {
		snprintf(buf, sizeof(buf), "%s", param_name);
	}
	rt = app_control_get_extra_data(app_control, buf, &data);

	if (rt == APP_CONTROL_ERROR_NONE){
		strcpy(target, data);
		memset(data, 0X00, strlen(data));
	} else {
		strcpy(target, "");
	}
	if (data != NULL){
		free(data);
	}
	_INFO("_get_extra_data:: %s = %s ", buf, target);
}

void _get_int_extra_data(app_control_h app_control, int *target, char *param_name, int num)
{
	LOGI("[IAP_SAMPLE] _get_int_extra_data()");

	char *data = NULL;
	int rt;
	char buf[100] = {0,};

	if (num >= 0){
		snprintf(buf, sizeof(buf), "%d%s", num, param_name);
	} else {
		snprintf(buf, sizeof(buf), "%s", param_name);
	}
	rt = app_control_get_extra_data(app_control, buf, &data);

	if (rt == APP_CONTROL_ERROR_NONE){
		*target = atoi(data);
		memset(data, 0X00, strlen(data));
	} else {
		*target = 0;
	}
	if (data != NULL){
		free(data);
	}
	_DBG("_get_extra_data:: %s = %d ", buf, *target);
}


void _app_control_error_popup(int rt)
{
	LOGI("[IAP_SAMPLE] _app_control_error_popup()  rt  : %d", rt);

	if (rt != APP_CONTROL_ERROR_NONE ){
		if (rt ==	APP_CONTROL_ERROR_INVALID_PARAMETER){
			iap_common_popup(ad->layout, "error", "APP_CONTROL ERROR INVALID PARAMETER");
		} else if (rt == APP_CONTROL_ERROR_INVALID_PARAMETER){
			iap_common_popup(ad->layout, "error", "APP_CONTROL ERROR INVALID PARAMETER");
		} else if (rt == APP_CONTROL_ERROR_OUT_OF_MEMORY){
			iap_common_popup(ad->layout, "error", "APP_CONTROL ERROR OUT OF MEMORY");
		} else if (rt == APP_CONTROL_ERROR_APP_NOT_FOUND){
			iap_common_popup(ad->layout, "error", "APP_CONTROL ERROR APP NOT FOUND");
		} else if (rt == APP_CONTROL_ERROR_LAUNCH_REJECTED){
			iap_common_popup(ad->layout, "error", "APP_CONTROL ERROR LAUNCH REJECTED");
		} else if (rt == APP_CONTROL_ERROR_PERMISSION_DENIED){
			iap_common_popup(ad->layout, "error", "APP_CONTROL ERROR PERMISSION DENIED");
		} else {
			iap_common_popup(ad->layout, "error", "APP_CONTROL - Unknown error.");
		}
	}
}

void btn_get_item_list_cb( void* data, Evas_Object* obj, void* event )
{
	LOGI("[IAP_SAMPLE] btn_get_item_list_cb() ");

	request_param_s *param = (request_param_s *)malloc(sizeof(request_param_s));
	memset(param, 0X00, sizeof(request_param_s));

	int rt = create_search_parameter(param);

	if (rt == 0){
		if (param->item_group_id == NULL || !strcmp("", param->item_group_id)){
			iap_common_popup(ad->layout, "error", "[Item group ID] is empty");
		} else if (param->item_type_cd == NULL || !strcmp("", param->item_type_cd)){
			iap_common_popup(ad->layout, "error", "[Item type code] is empty");
		} else {
			_get_item_list_operation_call(param);
		}
	} else{
		_ERR("param is null");
		iap_common_popup(ad->layout, "error", "parameter error!");
	}
}

void btn_purchase_cb( void* data, Evas_Object* obj, void* event )
{
	LOGI("[IAP_SAMPLE] btn_purchase_cb() ");

	item_s *item = (item_s *)data;
	request_param_s *param = (request_param_s *)malloc(sizeof(request_param_s));
	memset(param, 0X00, sizeof(request_param_s));

	int rt = create_search_parameter(param);

	if (rt == 0 && item != NULL){
		strcpy(param->item_id, item->item_id);
		strcpy(param->item_name, item->item_name);
		strcpy(param->item_group_id, item->item_group_id);

		_purchase_operation_call(param);
	} else {
		_ERR("param is null");
		iap_common_popup(ad->layout, "error", "parameter error!");
	}
}

void btn_get_purchased_item_list_cb( void* data, Evas_Object* obj, void* event )
{
	LOGI("[IAP_SAMPLE] btn_get_purchased_item_list_cb() ");
	request_param_s *param = (request_param_s *)malloc(sizeof(request_param_s));
	memset(param, 0X00, sizeof(request_param_s));

	int rt = create_search_parameter(param);

	if (rt == 0){
		if (param->item_group_id == NULL || !strcmp("", param->item_group_id)){
			iap_common_popup(ad->layout, "error", "[Item group ID] is empty");
		} else {
			_get_purchased_item_list_operation_call(param);
		}
	} else{
		_ERR("param is null");
		iap_common_popup(ad->layout, "error", "parameter error!");
	}
}

void btn_get_country_list_cb( void* data, Evas_Object* obj, void* event )
{
	LOGI("[IAP_SAMPLE] btn_get_country_list_cb() ");

	request_param_s *param;
	param = (request_param_s *)malloc(sizeof(request_param_s));
	memset(param, 0X00, sizeof(request_param_s));

	param->transaction_id = _make_transaction_id();

	_get_country_list_operation_call(param);
}

void get_country_list()
{
	LOGI("[IAP_SAMPLE] get_country_list() ");

	request_param_s *param;
	param = (request_param_s *)malloc(sizeof(request_param_s));
	memset(param, 0X00, sizeof(request_param_s));
	param->transaction_id = _make_transaction_id();

	_get_country_list_operation_call(param);
}
