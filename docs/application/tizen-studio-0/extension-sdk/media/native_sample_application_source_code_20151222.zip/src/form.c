/*
 * Copyright (c) 2014 Samsung Electronics Co., Ltd All Rights Reserved
 *
 * Licensed under the Apache License, Version 2.0 (the License);
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an AS IS BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <Elementary.h>
#include <download.h>

#include "dbg.h"
#include "define.h"
#include "common.h"
#include "iap.h"
#include "popup.h"

static int
_iap_create_win();

static Evas_Object*
_create_conform(Evas_Object *parent);

static int
_create_main_freme(appdata_s *ad);

static Evas_Object*
_create_drawer_layout(Evas_Object *parent);

static void
_select_mode_cb(void *data, Evas_Object *obj, void *event_info);

static int
_create_search_option(Evas_Object *parent);

static int
_create_item_genlist(item_list_s *list, iap_menu_e menu);

static Evas_Object*
_gl_config_option_cb(void *data, Evas_Object *obj, const char *part);

static char *
_gn_get_item_text_cb(void *data, Evas_Object *obj, const char *part);

static Evas_Object*
_gl_get_item_data_cb(void *data, Evas_Object *obj, const char *part);

static void
_input_popup_cb( void* data, Evas_Object* obj, void* event );

static void
_item_image_download(item_s *item);

static void
_image_download_and_save_set(char *url, const char *file_name, int *id);

static void
_image_download_cb(int download_id, download_state_e state, void *user_data);

static void
_image_download_callback_add(int id, download_state_changed_cb callback, void *data);

static void
_image_download_start(int id);

static void
_selected_genlist_row (void *data, Evas_Object *obj, void *event_info);



/*========================= Implement =====================*/

int _iap_create_win(){

	/* Window */
	ad->win = elm_win_util_standard_add(PACKAGE, PACKAGE);
	elm_win_autodel_set(ad->win, EINA_TRUE);

	if (elm_win_wm_rotation_supported_get(ad->win)) {
			int rots[4] = { 0, 90, 180, 270 };
			elm_win_wm_rotation_available_rotations_set(ad->win, (const int *)(&rots), 4);
		}
	return 0;
}

Evas_Object *
_create_conform(Evas_Object *parent)
{
	Evas_Object *conform, *bg;

	if (parent == NULL) return NULL;

	conform = elm_conformant_add(parent);
	evas_object_size_hint_weight_set(conform, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
	elm_win_resize_object_add(parent, conform);

	bg = elm_bg_add(conform);
	elm_object_style_set(bg, "indicator/headerbg");
	elm_object_part_content_set(conform, "elm.swallow.indicator_bg", bg);
	evas_object_show(bg);

	evas_object_show(conform);
	return conform;
}

int
_create_main_freme(appdata_s *ad){
	Evas_Object *box;
	Evas_Object *list;

	if(init_control_object() != 0){
		_ERR("control_object create fail.");
		return -1;
	}

	// init configuration data
	if (init_configuration() != 0){
		_ERR("configuration init fail.");
		return -1;
	}

	// init In-App Purchase result data variable
	init_iap_result();

	/* 전체 영역 Box */
	box = elm_box_add(ad->layout);
	if (box == NULL){
		return -1;
	}
	evas_object_size_hint_weight_set(box, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
	evas_object_size_hint_align_set(box, EVAS_HINT_FILL, EVAS_HINT_FILL);
	elm_object_part_content_set(ad->layout, "elm.swallow.content", box);


	list = elm_genlist_add(box);
	elm_genlist_block_count_set(list, 1);
	elm_genlist_homogeneous_set(list, EINA_TRUE);
	elm_genlist_mode_set(list, ELM_LIST_COMPRESS);
	evas_object_size_hint_weight_set(list, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
	evas_object_size_hint_align_set(list, EVAS_HINT_FILL, EVAS_HINT_FILL);
	elm_box_pack_end(box, list);

	ad->genlist = list;

	/* 검색 옵션 생성 */
	if (_create_search_option(box) != 0){
		_ERR("search option create fail.");
		return -1;
	}

	ad->box = box;

	evas_object_show(ad->layout);

	return 0;
}

Evas_Object *
_create_drawer_layout(Evas_Object *parent)
{
	Evas_Object *layout;
	layout = elm_layout_add(parent);
	elm_layout_theme_set(layout, "layout", "drawer", "panel");
	evas_object_show(layout);

	return layout;
}

void
_select_mode_cb(void *data, Evas_Object *obj, void *event_info){

	char *mode;

	mode = (char *)data;

	if (search_config == NULL){
		search_config = (search_config_s *)malloc(sizeof(search_config_s));
		memset(search_config, 0X00, sizeof(search_config_s));
	}

	if (mode != NULL && strlen(mode) != 0){

		if (!strcmp(MODE_NORMAL, mode)){
			free_configuration();
		}
		if (search_config == NULL){
			init_configuration();
		}
		strcpy(search_config->mode, mode);

		elm_genlist_clear(ad->genlist);
		int ret = _create_search_option(ad->box);

		_DBG("_create_search_option : ret= %d", ret);

	} else {
		_ERR("search_config is null\\n mode change failed!");
	}
}

int
_create_search_option(Evas_Object *parent){

	_DBG("_create_search_option");


	if (control_object){

		if (control_object->mode) {
			evas_object_del(control_object->mode);
		}
		if (control_object->mcc) {
			evas_object_del(control_object->mcc);
		}
		if (control_object->mnc) {
			evas_object_del(control_object->mnc);
		}
		if (control_object->item_group_id) {
			evas_object_del(control_object->item_group_id);
		}
		if (control_object->item_type_code) {
			evas_object_del(control_object->item_type_code);
		}

		free(control_object);
		memset(control_object, 0X00, sizeof(control_object_s));
		control_object = NULL;
	}
	init_control_object();


	/* Create item class */
	Elm_Genlist_Item_Class *itc = elm_genlist_item_class_new();

	if (itc != NULL) {

		itc->item_style = "1icon";
		itc->delete_me = 0;
		itc->func.content_get = _gl_config_option_cb;
		itc->func.text_get = NULL;
		itc->func.del = NULL;
		itc->func.state_get = NULL;

		evas_object_show(ad->genlist);

		elm_genlist_item_append(ad->genlist, itc, "mode", NULL, ELM_GENLIST_ITEM_NONE, NULL, NULL);

		if (strcmp(MODE_DEVELOPER, search_config->mode) == 0){
			elm_genlist_item_append(ad->genlist, itc, IAP_SEARCH_OPTION_MCC, NULL, ELM_GENLIST_ITEM_NONE, NULL, NULL);
			elm_genlist_item_append(ad->genlist, itc, IAP_SEARCH_OPTION_ITEM_GROUP_ID, NULL, ELM_GENLIST_ITEM_NONE, NULL, NULL);
			elm_genlist_item_append(ad->genlist, itc, IAP_SEARCH_OPTION_ITEM_TYPE_CODE, NULL, ELM_GENLIST_ITEM_NONE, NULL, NULL);
		}
		elm_genlist_item_append(ad->genlist, itc, "btn_item_list", NULL, ELM_GENLIST_ITEM_NONE, NULL, NULL);
		elm_genlist_item_append(ad->genlist, itc, "btn_purchased_item_list", NULL, ELM_GENLIST_ITEM_NONE, NULL, NULL);


		elm_genlist_item_class_free(itc);



	} else {
		return -1;
	}

	return 0;
}

int
_create_item_genlist(item_list_s *list, iap_menu_e menu){

	if (ad->box != NULL){

		/* Create item class */
		Elm_Genlist_Item_Class *itc = elm_genlist_item_class_new();

		if (itc != NULL) {
			itc->item_style = "2line.top.3";
			itc->func.content_get = _gl_get_item_data_cb;
			itc->func.text_get = _gn_get_item_text_cb;
			itc->func.del = NULL;

			int str_len = 0;

			_INFO("items size : %d", list->item_size);
			if (list->items != NULL && list->item_size > 0){
				int i;
				Elm_Object_Item *it;
				for(i = 0; i < list->item_size; i++){

					//item image file download
					if (list->items[i]->item_image_url ){
						str_len = strlen(list->items[i]->item_image_url);
						if (str_len > 0){
							_item_image_download(list->items[i]);
						} else {
							strcpy(list->items[i]->item_image_path, TIZEN_ICON);
						}
					} else {
						strcpy(list->items[i]->item_image_path, TIZEN_ICON);
					}

					if (menu == FUNC_GET_PURCHASED_ITEM_LIST){
						list->items[i]->is_purchased = 1;
					} else {
						list->items[i]->is_purchased = 0;
					}
					it = elm_genlist_item_append(ad->genlist,		/* genlist object */
											itc,						/* item class */
											list->items[i], 			/* item class user data */
											NULL,						/* parent object */
											ELM_GENLIST_ITEM_NONE,		/* item type */
											_selected_genlist_row,		/* select smart callback */
											NULL);						/* smart callback user data */


					list->items[i]->elm_item = it;

				}
			}

			elm_genlist_item_class_free(itc);
		} else {
			return -1;
		}
	}


	return 0;
}

Evas_Object*
_gl_config_option_cb(void *data, Evas_Object *obj, const char *part)
{

	_DBG("type : %s", (char*)data);

	char* type = (char *)data;
	Evas_Object *content = NULL;

	Evas_Object *edit_box = elm_box_add(obj);
	evas_object_size_hint_weight_set(edit_box, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
	evas_object_size_hint_align_set(edit_box, EVAS_HINT_FILL, EVAS_HINT_FILL);
	elm_box_padding_set(edit_box, 15, 0);
	elm_box_horizontal_set(edit_box, EINA_TRUE);
	elm_box_pack_end(obj, edit_box);
	evas_object_show(edit_box);

	Evas_Object *label;
	Evas_Object *btn;

	if (strcmp(type, "mode") == 0){
		Evas_Object *radio, *radio_group;


		_INFO("mode : %d, address : %x", ad->mode, &(ad->mode));


		label = elm_label_add(obj);
		elm_object_text_set(label, "<font color='#B91A4D'>Mode</font>");
		elm_box_pack_end(edit_box, label);
		evas_object_show(label);

		radio = radio_group = elm_radio_add(obj);
		elm_radio_group_add(radio, radio_group);
		elm_radio_state_value_set(radio, atoi(MODE_NORMAL));
		elm_radio_value_pointer_set(radio, &(ad->mode));
		evas_object_smart_callback_add(radio, "changed", _select_mode_cb, MODE_NORMAL);
		elm_box_pack_end(edit_box, radio);
		evas_object_show(radio);

		label = elm_label_add(obj);
		elm_object_text_set(label, "Normal");
		elm_box_pack_end(edit_box, label);
		evas_object_show(label);

		radio = elm_radio_add(obj);
		elm_radio_group_add(radio, radio_group);
		elm_radio_state_value_set(radio, atoi(MODE_DEVELOPER));
		elm_radio_value_pointer_set(radio, &(ad->mode));
		evas_object_smart_callback_add(radio, "changed", _select_mode_cb, MODE_DEVELOPER);
		elm_box_pack_end(edit_box, radio);
		evas_object_show(radio);

		label = elm_label_add(obj);
		elm_object_text_set(label, "Developer");
		elm_box_pack_end(edit_box, label);
		evas_object_show(label);
	} else if (strcmp(type, IAP_SEARCH_OPTION_MCC) == 0){
		label = elm_label_add(obj);
		elm_object_text_set(label, "<font color='#B91A4D'>MCC</font>");
		elm_box_pack_end(edit_box, label);
		evas_object_show(label);

		Evas_Object *ef_mcc;
		ef_mcc = elm_entry_add(obj);
		elm_entry_single_line_set(ef_mcc, EINA_TRUE);

		evas_object_size_hint_weight_set(ef_mcc, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
		evas_object_size_hint_align_set(ef_mcc, EVAS_HINT_FILL, EVAS_HINT_FILL);
		elm_entry_autosave_set(ef_mcc, EINA_FALSE);
		elm_entry_editable_set(ef_mcc, EINA_FALSE);
		elm_entry_prediction_allow_set(ef_mcc, EINA_FALSE);
		elm_object_domain_translatable_part_text_set(ef_mcc, "elm.guide", "sys_string", "click here");

		evas_object_smart_callback_add(ef_mcc, "clicked", _input_popup_cb, IAP_SEARCH_OPTION_MCC);

		elm_box_pack_end(edit_box, ef_mcc);
		evas_object_show(ef_mcc);


		if (search_config != NULL){
			if ((search_config->mcc) != NULL && strlen(search_config->mcc) > 0){
				_INFO("search_config->mcc : %s", search_config->mcc);
				elm_entry_entry_set(ef_mcc, search_config->mcc);
				elm_object_domain_translatable_part_text_set(ef_mcc, "elm.guide", "sys_string", "");
			}
		}

		label = elm_label_add(obj);
		elm_object_text_set(label, "<font color='#B91A4D'>MNC</font>");
		elm_box_pack_end(edit_box, label);
		evas_object_show(label);

		Evas_Object *ef_mnc;
		ef_mnc = elm_entry_add(obj);
		elm_entry_single_line_set(ef_mnc, EINA_TRUE);
		evas_object_size_hint_weight_set(ef_mnc, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
		evas_object_size_hint_align_set(ef_mnc, EVAS_HINT_FILL, EVAS_HINT_FILL);
		elm_entry_autosave_set(ef_mnc, EINA_FALSE);
		elm_entry_editable_set(ef_mnc, EINA_FALSE);
		elm_entry_prediction_allow_set(ef_mnc, EINA_FALSE);
		elm_object_domain_translatable_part_text_set(ef_mnc, "elm.guide", "sys_string", "click here");

		evas_object_smart_callback_add(ef_mnc, "clicked", _input_popup_cb, IAP_SEARCH_OPTION_MNC);

		elm_box_pack_end(edit_box, ef_mnc);
		evas_object_show(ef_mnc);

		if (search_config != NULL){
			if (search_config->mnc != NULL && strlen(search_config->mnc) > 0){
				elm_entry_entry_set(ef_mnc, search_config->mnc);
				elm_object_domain_translatable_part_text_set(ef_mnc, "elm.guide", "sys_string", "");
			}
		}

		control_object->mcc = ef_mcc;
		control_object->mnc = ef_mnc;
	} else if (strcmp(type, IAP_SEARCH_OPTION_MNC) == 0){
		label = elm_label_add(obj);
		elm_object_text_set(label, "<font color='#B91A4D'>MNC</font>");
		elm_box_pack_end(edit_box, label);
		evas_object_show(label);

		Evas_Object *ef_mnc;
		ef_mnc = elm_entry_add(obj);
		elm_entry_single_line_set(ef_mnc, EINA_TRUE);
		evas_object_size_hint_weight_set(ef_mnc, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
		evas_object_size_hint_align_set(ef_mnc, EVAS_HINT_FILL, EVAS_HINT_FILL);
		elm_entry_autosave_set(ef_mnc, EINA_FALSE);
		elm_entry_editable_set(ef_mnc, EINA_FALSE);
		elm_entry_prediction_allow_set(ef_mnc, EINA_FALSE);
		elm_object_domain_translatable_part_text_set(ef_mnc, "elm.guide", "sys_string", "click here");

		evas_object_smart_callback_add(ef_mnc, "clicked", _input_popup_cb, IAP_SEARCH_OPTION_MNC);

		if (search_config != NULL){
			if (search_config->mnc != NULL && strlen(search_config->mnc) > 0){
				elm_entry_entry_set(ef_mnc, search_config->mnc);
				elm_object_domain_translatable_part_text_set(ef_mnc, "elm.guide", "sys_string", "");
			}
		}

		elm_box_pack_end(edit_box, ef_mnc);
		evas_object_show(ef_mnc);
	} else if (strcmp(type, IAP_SEARCH_OPTION_ITEM_GROUP_ID) == 0){
		label = elm_label_add(obj);
		elm_object_text_set(label, "<font color='#B91A4D'>Item Group ID</font>");
		elm_box_pack_end(edit_box, label);
		evas_object_show(label);

		Evas_Object *ef_item_group_id;
		ef_item_group_id = elm_entry_add(obj);
		elm_entry_single_line_set(ef_item_group_id, EINA_TRUE);
		evas_object_size_hint_weight_set(ef_item_group_id, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
		evas_object_size_hint_align_set(ef_item_group_id, EVAS_HINT_FILL, EVAS_HINT_FILL);
		elm_entry_autosave_set(ef_item_group_id, EINA_FALSE);
		elm_entry_editable_set(ef_item_group_id, EINA_FALSE);
		elm_entry_prediction_allow_set(ef_item_group_id, EINA_FALSE);
		elm_object_domain_translatable_part_text_set(ef_item_group_id, "elm.guide", "sys_string", "click here");

		evas_object_smart_callback_add(ef_item_group_id, "clicked", _input_popup_cb, IAP_SEARCH_OPTION_ITEM_GROUP_ID);

		elm_box_pack_end(edit_box, ef_item_group_id);
		evas_object_show(ef_item_group_id);

		if (search_config != NULL){
			if (search_config->item_group_id != NULL && strlen(search_config->item_group_id) > 0){
				elm_entry_entry_set(ef_item_group_id, search_config->item_group_id);
				elm_object_domain_translatable_part_text_set(ef_item_group_id, "elm.guide", "sys_string", "");
			}
		}

		control_object->item_group_id = ef_item_group_id;
	} else if (strcmp(type, IAP_SEARCH_OPTION_ITEM_TYPE_CODE) == 0){
		label = elm_label_add(obj);
		elm_object_text_set(label, "<font color='#B91A4D'>Item type code</font>");
		elm_box_pack_end(edit_box, label);
		evas_object_show(label);

		Evas_Object *ef_item_type;
		ef_item_type = elm_entry_add(obj);
		elm_entry_single_line_set(ef_item_type, EINA_TRUE);
		evas_object_size_hint_weight_set(ef_item_type, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
		evas_object_size_hint_align_set(ef_item_type, EVAS_HINT_FILL, EVAS_HINT_FILL);

		elm_entry_editable_set(ef_item_type, EINA_FALSE);
		elm_entry_prediction_allow_set(ef_item_type, EINA_FALSE);
		elm_object_domain_translatable_part_text_set(ef_item_type, "elm.guide", "sys_string", "click here");

		evas_object_smart_callback_add(ef_item_type, "clicked", _input_popup_cb, IAP_SEARCH_OPTION_ITEM_TYPE_CODE);

		elm_box_pack_end(edit_box, ef_item_type);
		evas_object_show(ef_item_type);

		if (search_config != NULL){
			if (search_config->item_type_code != NULL && strlen(search_config->item_type_code) > 0){
				elm_entry_entry_set(ef_item_type, search_config->item_type_code);
				elm_object_domain_translatable_part_text_set(ef_item_type, "elm.guide", "sys_string", "");
			}
		}

		control_object->item_type_code = ef_item_type;
	} else if (strcmp(type, "btn_country_list") == 0){

		btn = elm_button_add(obj);
		elm_object_text_set(btn, "get_country_list");
		elm_object_style_set(btn, "contacts");
		evas_object_size_hint_weight_set(btn, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
		evas_object_size_hint_align_set( btn, EVAS_HINT_FILL, EVAS_HINT_FILL );
		evas_object_smart_callback_add(btn, "clicked", btn_get_country_list_cb, NULL);
		elm_box_pack_end(edit_box, btn);
		evas_object_show(btn);



	} else if (strcmp(type, "btn_item_list") == 0){

		btn = elm_button_add(obj);
		char fullText[256] = {0,};
		snprintf(fullText, 256, "<color=#FFFFFF><align=center>%s</align></color>","get_item_list");
		elm_object_text_set(btn, fullText);
		evas_object_size_hint_weight_set(btn, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
		evas_object_size_hint_align_set( btn, EVAS_HINT_FILL, 0.5 );
		evas_object_smart_callback_add(btn, "clicked", btn_get_item_list_cb, NULL);
		elm_box_pack_end(edit_box, btn);
		evas_object_show(btn);

	} else if (strcmp(type, "btn_purchased_item_list") == 0){

		btn = elm_button_add(obj);
		char fullText[256] = {0,};
		snprintf(fullText, 256, "<color=#FFFFFF><align=center>%s</align></color>","get_purchased_item_list");
		elm_object_text_set(btn, fullText);
		evas_object_size_hint_weight_set(btn, 0.5, EVAS_HINT_EXPAND);
		evas_object_size_hint_align_set( btn, EVAS_HINT_FILL, 0.5 );
		evas_object_smart_callback_add(btn, "clicked", btn_get_purchased_item_list_cb, NULL);
		elm_box_pack_end(edit_box, btn);
		evas_object_show(btn);
	}

    content = edit_box;

	return content;
}

char *
_gn_get_item_text_cb(void *data, Evas_Object *obj, const char *part){

	char buf[1024] = {0,};
	item_s *item = (item_s *)data;
	char *item_type = NULL;
	char item_price[100] = {0,};
	bool item_reduced_yn = false;

	if (item) {
		if (!strcmp(part, "elm.text.main.left.top")){
			return strdup(item->item_name);
		} else 	if (!strcmp(part, "elm.text.sub.left.bottom")){
			if (!strcmp(ITEM_TYPE_CODE_CONSUMABLE, item->item_type_cd)){
				item_type = ITEM_TYPE_NAME_CONSUMABLE;
			} else if (!strcmp(ITEM_TYPE_CODE_NON_CONSUMABLE, item->item_type_cd)){
				item_type = ITEM_TYPE_NAME_NON_CONSUMABLE;
			} else if (!strcmp(ITEM_TYPE_CODE_SUBSCRIPTION, item->item_type_cd)){
				item_type = ITEM_TYPE_NAME_SUBSCRIPTION;
			}

			//check discount flag and reduced price
			if (item->item_discount_flag) {
				if (!strcmp(item->item_discount_flag, "Y")) {
					if (item->item_reduced_price) {
						if (atof(item->item_reduced_price) >= 0) {
							item_reduced_yn = true;
						}
					}
				}
			}

			if ( item_reduced_yn ) {
				if (!strcmp(UNIT_PRECEDES_RIGHT, item->unit_precedes)){
					snprintf(item_price, sizeof(item_price), "<strikethrough=on strikethrough_color=#000000>%s %s</strikethrough> %s %s", item->item_price, item->currency_unit, item->item_reduced_price, item->currency_unit);
				} else {
					snprintf(item_price, sizeof(item_price), "<strikethrough=on strikethrough_color=#000000>%s %s</strikethrough> %s %s", item->currency_unit, item->item_price, item->currency_unit, item->item_reduced_price);
				}
			} else {
				if (!strcmp(UNIT_PRECEDES_RIGHT, item->unit_precedes)){
					snprintf(item_price, sizeof(item_price), "%s %s", item->item_price, item->currency_unit);
				} else {
					snprintf(item_price, sizeof(item_price), "%s %s", item->currency_unit, item->item_price);
				}
			}

			if (item->is_purchased == 1){

				char purchaseDate[32] = {0x00};
				snprintf(purchaseDate, sizeof(purchaseDate), "%s", item->purchase_date);

				char *token_year = strtok(purchaseDate, ";");
				char *token_month = strtok(NULL, ";");
				char *token_day = strtok(NULL, ";");
				char *token_hour = strtok(NULL, ";");
				char *token_minute = strtok(NULL, ";");
				char *token_second = strtok(NULL, ";");

				snprintf(buf, sizeof(buf), "%s / %s-%s-%s %s:%s:%s", item_price, token_year, token_month, token_day, token_hour, token_minute, token_second);
			} else {
				snprintf(buf, sizeof(buf), "%s (%s)", item_price, item_type);
			}

			return strdup(buf);
		} else {
			return NULL;
		}
	} else {
		return NULL;
	}
}

Evas_Object*
_gl_get_item_data_cb(void *data, Evas_Object *obj, const char *part)
{
	item_s *item = (item_s *)data;
	Evas_Object *content = NULL;

	Evas_Object *ic;
	Evas_Object *c;
	Evas_Object *btn;

	ic = elm_layout_add(obj);

	if (!strcmp(part, "elm.icon.1")){

		elm_layout_theme_set(ic, "layout", "list/B/type.2", "default");

		c = elm_image_add(obj);
		elm_image_file_set(c, item->item_image_path, NULL);
		evas_object_size_hint_align_set(c, EVAS_HINT_FILL, EVAS_HINT_FILL);
		evas_object_size_hint_weight_set(c, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
		elm_layout_content_set(ic, "elm.swallow.content", c);
		evas_object_show(c);
	} else if (!strcmp(part, "elm.icon.right")) {

		if (item->is_purchased == 0){
			//Button
			btn = elm_button_add(obj);
			elm_layout_theme_set(ic, "layout", "list/A/right.icon", "default");
			elm_object_text_set(btn, "Buy");
			evas_object_size_hint_weight_set(btn, EVAS_HINT_EXPAND, 0.5);
			evas_object_size_hint_align_set( btn, EVAS_HINT_FILL, EVAS_HINT_FILL );
			evas_object_smart_callback_add(btn, "clicked", btn_purchase_cb, item);
			elm_layout_content_set(ic, "elm.swallow.content", btn);
			evas_object_size_hint_min_set(btn, 80, 0);
			evas_object_show(btn);
		}
	}

	evas_object_show(ic);

    content = ic;

	return content;
}


void
_input_popup_cb( void* data, Evas_Object* obj, void* event ){

	if (!strcmp(IAP_SEARCH_OPTION_ITEM_TYPE_CODE, (char *)data)){
		iap_item_type_popup(ad->layout, (const char *)data);
	} else if (!strcmp(IAP_SEARCH_OPTION_MCC, (char *)data)){
		get_country_list();
	} else if (!strcmp(IAP_SEARCH_OPTION_MNC, (char *)data)){
		get_country_list();
	} else {
		iap_input_popup(ad->layout, (const char *)data);
	}
}


void
_item_image_download(item_s *item){

	int id;


	_image_download_and_save_set(item->item_image_url, NULL, &id);
	_image_download_callback_add(id, _image_download_cb, item);
	_image_download_start(id);

//	ecore_main_loop_begin();
}

void
_image_download_cb(int download_id, download_state_e state, void *user_data){

	char *file_path;
	item_s *item;

	item = (item_s *)user_data;


	if (state == DOWNLOAD_STATE_COMPLETED){

		download_get_downloaded_file_path(download_id, &file_path);
		download_destroy(download_id);

		if (file_path){
			strcpy(item->item_image_path, file_path);
			elm_genlist_item_fields_update(item->elm_item, "elm.icon.1", ELM_GENLIST_ITEM_FIELD_CONTENT );
		}
	} else {

		// 이미지가 다운로드가 실패하면 타이젠 아이콘으로 이미지객체를 생성하도록 요청한다.

		if (state == DOWNLOAD_STATE_NONE){
			_INFO("IMAGE DOWNLOAD STATE : DOWNLOAD_STATE_NONE");

		} else if(state == DOWNLOAD_STATE_READY){
			_INFO("IMAGE DOWNLOAD STATE : DOWNLOAD_STATE_READY");

		} else if(state == DOWNLOAD_STATE_QUEUED){
			_INFO("IMAGE DOWNLOAD STATE : DOWNLOAD_STATE_QUEUED");

		} else if(state == DOWNLOAD_STATE_DOWNLOADING){
			_INFO("IMAGE DOWNLOAD STATE : DOWNLOAD_STATE_DOWNLOADING");

		} else if(state == DOWNLOAD_STATE_PAUSED){
			_INFO("IMAGE DOWNLOAD STATE : DOWNLOAD_STATE_PAUSED");

		} else if(state == DOWNLOAD_STATE_FAILED || state == DOWNLOAD_STATE_CANCELED){

			_ERR("IMAGE DOWNLOAD STATE : DOWNLOAD_STATE_FAILED OR DOWNLOAD_STATE_CANCELED");
			download_destroy(download_id);
			strcpy(item->item_image_path, TIZEN_ICON);
			_DBG(">>>>>>>>>>> img pasth :%s", TIZEN_ICON);
		} else {

			_ERR("IMAGE DOWNLOAD STATE : Unknown error");
			download_destroy(download_id);
			strcpy(item->item_image_path, TIZEN_ICON);
			_DBG(">>>>>>>>>>> img pasth :%s", TIZEN_ICON);
		}


	}
}

void
_image_download_and_save_set(char *url, const char *file_name, int *id) {

	download_create(id);

	if (*id > 0 ){
		download_set_url(*id, url);
		download_set_network_type(*id, DOWNLOAD_NETWORK_ALL);
		download_set_destination(*id, NULL);
		if(file_name != NULL &&   strcmp(file_name, "") != 0 ){
			download_set_file_name(*id, file_name);
		}
	}
}

void
_image_download_callback_add(int id, download_state_changed_cb callback, void *data) {
	if (id > 0 ){
		download_set_state_changed_cb(id, callback, data);
	}
}

void
_image_download_start(int id) {
	if (id > 0 ){
		download_start(id);
	}
}
void
_selected_genlist_row (void *data, Evas_Object *obj, void *event_info){

	_INFO("_selected_genlist_row ");

	if(obj) {
		Elm_Object_Item *it = elm_genlist_selected_item_get (obj);
		if (it) {
			elm_genlist_item_selected_set(it, EINA_FALSE);
		}
	}
}

/**
 *
 * Create application main UI
 *
 */
int iap_create_form(appdata_s *ad){

	// create window
	if (_iap_create_win() != 0){
		return -1;
	}

	// conforment
	ad->conform = _create_conform(ad->win);
	elm_win_conformant_set(ad->win, EINA_TRUE);

	// Naviframe
	ad->nf = elm_naviframe_add(ad->conform);
	elm_object_content_set(ad->conform, ad->nf);

	// Layout
	ad->layout = _create_drawer_layout(ad->nf);

    elm_win_indicator_type_set( ad->win, ELM_WIN_INDICATOR_TYPE_1);
    elm_win_indicator_mode_set( ad->win, ELM_WIN_INDICATOR_SHOW);

	// main frame
	if (_create_main_freme(ad) != 0) {
		_ERR("create main frame fail.");
		return -1;
	}

	// init mcc, mnc hashmap
	init_country_hash();

	elm_naviframe_item_push(ad->nf, "IAP Test(1Way)", NULL, NULL, ad->layout, "basic");

	return 0;
}

/**
 *
 *  Show response data from in-app purchase
 */
void
create_result_view(iap_menu_e menu, void* data)
{
	_INFO("create_result_view start");

	if (menu == FUNC_GET_COUNTRY_LIST){

		country_list_s* country_list;
		country_list = (country_list_s *)data;

		if (country_list != NULL){
			if (!strcmp(RESULT_SUCCESS, country_list->result)){

				if (country_list->item_size <= 0){
					iap_common_popup(ad->layout, "Info", "No data");
				} else {
					// get_country_list 결과를 팝업을 통해 보여준다
					iap_country_list_popup(ad->layout, country_list, "Select country");
				}
			} else {
				iap_common_popup(ad->layout, "error", get_iap_result_message(country_list->result));
			}
		}
	} else if (menu == FUNC_GET_ITEM_LIST || menu == FUNC_GET_PURCHASED_ITEM_LIST){
		item_list_s* item_list;
		item_list = (item_list_s *)data;

		if (item_list != NULL){

			elm_genlist_clear(ad->genlist);
			_create_search_option(ad->box);

			if (!strcmp(RESULT_SUCCESS, item_list->result)){

				if (item_list->item_size == 0){
					// if not exist product, show error popup
					iap_common_popup(ad->layout, "Info", "No data");
				} else if (item_list->items != NULL && item_list->item_size > 0){
					// show product
					_create_item_genlist(item_list, menu);
				}
			} else {
				// if error return, show error popup
				iap_common_popup(ad->layout, "error", get_iap_result_message(item_list->result));
			}
		}
	} else if (menu == FUNC_PURCHASE){
		purchase_s* result = (purchase_s *)data;

		if (result != NULL){
			if (!strcmp(RESULT_SUCCESS, result->result)){
				// if success
				iap_popup_purchase_success(ad->layout, "info", "Purchase success! Would you open a purchase verify URL?", result);
			} else {
				// if fail
				iap_common_popup(ad->layout, "error", get_iap_result_message(result->result));
			}
		}
	}
}
