#include <Elementary.h>
#include <app_control.h>
#include <system_info.h>

#include "dbg.h"
#include "define.h"
#include "common.h"
#include "form.h"

#define DEVICE_RESOLUTION_WVGA 480
#define DEVICE_RESOLUTION_HD 720

static Evas_Object *
_iap_form_popup_add( Evas_Object* parent, const char* title, const char *body);

static void
_popup_btn_confirm_cb( void* data, Evas_Object* obj, void* event );

static void
_popup_btn_cancel_cb( void* data, Evas_Object* obj, void* event );

static char*
_gl_get_item_type_text_cb(void *data, Evas_Object *obj, const char *part);

static Evas_Object*
_gl_get_item_type_object_cb(void *data, Evas_Object *obj, const char *part);

static void
_btn_select_item_type_cb( void* data, Evas_Object* obj, void* event );

static char*
_gl_get_country_text_cb(void *data, Evas_Object *obj, const char *part);

static Evas_Object*
_gl_get_country_data_cb(void *data, Evas_Object *obj, const char *part);

static void
_btn_select_country_cb( void* data, Evas_Object* obj, void* event );

static void
_entry_click_cb(void *data, Evas_Object *obj, void *event_info);

static void
_init_loading();

static Eina_Bool
_timeOut_timer_cb(void* data);

static void
_popup_btn_purchase_verify_url_open( void* data, Evas_Object* obj, void* event );

void iap_input_popup(Evas_Object *parent, const char *data)
{
	char *target = (char *)data;
	Evas_Object *editfield;
	Evas_Object *popup;
	Evas_Object *box;

	popup = _iap_form_popup_add(parent, target, NULL);
	ad->popup = popup;

	evas_object_event_callback_add(popup, EVAS_CALLBACK_DEL, NULL, NULL);
	evas_object_size_hint_weight_set(popup, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);

	box = elm_box_add(popup);
	evas_object_size_hint_weight_set(box, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
	evas_object_size_hint_align_set(box, 0, 1);
	elm_box_horizontal_set(box, EINA_FALSE);
	elm_object_content_set(popup, box);
	evas_object_show(box);

	editfield = elm_entry_add(popup);
	elm_entry_single_line_set(editfield, EINA_TRUE);
	evas_object_size_hint_weight_set(editfield, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
	evas_object_size_hint_align_set(editfield, EVAS_HINT_FILL, EVAS_HINT_FILL);
	evas_object_smart_callback_add(editfield, "activated", NULL, NULL);
	evas_object_smart_callback_add(editfield, "clicked", _entry_click_cb, NULL);
	elm_object_domain_translatable_part_text_set(editfield, "elm.guide", "sys_string", "click here"); // Add guide text to elm_entry.

	elm_entry_editable_set(editfield, EINA_TRUE);
	elm_entry_autosave_set(editfield, EINA_FALSE);
	elm_entry_cursor_begin_set (editfield);

	elm_entry_input_panel_enabled_set(editfield, EINA_TRUE);
	elm_entry_prediction_allow_set(editfield, EINA_FALSE);
	elm_entry_input_panel_layout_set(editfield,ELM_INPUT_PANEL_LAYOUT_NUMBERONLY);
	elm_entry_input_panel_return_key_type_set(editfield, ELM_INPUT_PANEL_RETURN_KEY_TYPE_DONE);

	elm_box_pack_end(box, editfield);
	evas_object_show(editfield);
	evas_object_focus_set(editfield, EINA_TRUE);
	elm_object_focus_set (editfield, EINA_TRUE);
	elm_entry_input_panel_show(editfield);

	ad->popup_ef = editfield;

	if (!strcmp(target, IAP_SEARCH_OPTION_ITEM_GROUP_ID)){
		const char *item_group_id = elm_entry_entry_get(control_object->item_group_id);

		if (item_group_id != NULL)		{
			elm_entry_entry_set(editfield, item_group_id);
		}
	}

	Evas_Object *btn;
	btn = elm_button_add(popup);
	elm_object_text_set(btn, "Cancel");
	elm_object_part_content_set( popup, "button1", btn);
	evas_object_smart_callback_add(btn, "clicked", _popup_btn_cancel_cb, target);
	evas_object_show(btn);

	btn = elm_button_add(popup);
	elm_object_text_set(btn, "Confirm");
	elm_object_part_content_set( popup, "button2", btn);
	evas_object_smart_callback_add(btn, "clicked", _popup_btn_confirm_cb, target);
	evas_object_show(btn);

    evas_object_show(popup);
}



void iap_item_type_popup(Evas_Object *parent, const char *data)
{
	char *target = (char *)data;
	Evas_Object *popup;
	Evas_Object *box;

	init_item_type();

	char *pszAPIVersion = NULL;
	int r = system_info_get_platform_string("tizen.org/feature/platform.version", &pszAPIVersion);
	if(r != SYSTEM_INFO_ERROR_NONE)
	{
		_ERR("[IAP_Sample]Platform version check failed");
		return;
	}

	popup = _iap_form_popup_add(parent, target, NULL);
	ad->popup = popup;

	evas_object_event_callback_add(popup, EVAS_CALLBACK_DEL, NULL, NULL);
	evas_object_size_hint_weight_set(popup, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);

	box = elm_box_add(popup);
	_ERR("[IAP_Sample] pszAPIVersion  : %s",pszAPIVersion);
	if(pszAPIVersion){
		if(strncmp(pszAPIVersion,"2.3",3) == 0)
			evas_object_size_hint_min_set(box, 0, 380);
		else if(strncmp(pszAPIVersion,"2.4",3) == 0)
			evas_object_size_hint_min_set(box, 0, 380+100);
	}else
		evas_object_size_hint_min_set(box, 0, 380+100);

	elm_box_horizontal_set(box, EINA_FALSE);
	elm_object_content_set(popup, box);
	evas_object_show(box);

	/* Create item class */
	Elm_Genlist_Item_Class *itc = elm_genlist_item_class_new();

	if (itc != NULL) {
		//itc->item_style = "1line";
		itc->item_style = "end_icon";
		itc->func.content_get = _gl_get_item_type_object_cb;
		itc->func.text_get = _gl_get_item_type_text_cb;
		itc->func.del = NULL;

		Evas_Object *genlist = elm_genlist_add(popup);
		elm_genlist_block_count_set(genlist, 10);
		elm_genlist_homogeneous_set(genlist, EINA_TRUE);
		elm_genlist_mode_set(genlist, ELM_LIST_COMPRESS);
		evas_object_size_hint_weight_set(genlist, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
		evas_object_size_hint_align_set(genlist, EVAS_HINT_FILL, EVAS_HINT_FILL);
		elm_box_pack_end(box, genlist);
		evas_object_show(genlist);

		elm_genlist_item_append(genlist, itc, item_types[0], NULL, ELM_GENLIST_ITEM_NONE, NULL, NULL);
		elm_genlist_item_append(genlist, itc, item_types[1], NULL, ELM_GENLIST_ITEM_NONE, NULL, NULL);
		elm_genlist_item_append(genlist, itc, item_types[2], NULL, ELM_GENLIST_ITEM_NONE, NULL, NULL);
		elm_genlist_item_append(genlist, itc, item_types[3], NULL, ELM_GENLIST_ITEM_NONE, NULL, NULL);

		elm_genlist_item_class_free(itc);
	}


    evas_object_show(popup);
}

void iap_country_list_popup(Evas_Object *parent, country_list_s *list, const char *data)
{

	_INFO("call iap_country_list_popup");

	char *target = (char *)data;
	Evas_Object *popup;
	Evas_Object *box;

	popup = _iap_form_popup_add(parent, target, NULL);
	ad->popup = popup;

	evas_object_event_callback_add(popup, EVAS_CALLBACK_DEL, NULL, NULL);
	evas_object_size_hint_weight_set(popup, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);

	box = elm_box_add(popup);
	evas_object_size_hint_min_set(box, 0, 285+80);
	elm_box_horizontal_set(box, EINA_FALSE);
	elm_object_content_set(popup, box);
	evas_object_show(box);

	/* Create item class */
	Elm_Genlist_Item_Class *itc = elm_genlist_item_class_new();

	if (itc != NULL) {

		itc->item_style = "end_icon";
		itc->func.content_get = _gl_get_country_data_cb;
		itc->func.text_get = _gl_get_country_text_cb;
		itc->func.del = NULL;

		Evas_Object *genlist = elm_genlist_add(popup);
		elm_genlist_block_count_set(genlist, 10);
		elm_genlist_homogeneous_set(genlist, EINA_TRUE);
		elm_genlist_mode_set(genlist, ELM_LIST_COMPRESS);
		evas_object_size_hint_weight_set(genlist, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
		evas_object_size_hint_align_set(genlist, EVAS_HINT_FILL, EVAS_HINT_FILL);
		elm_box_pack_end(box, genlist);
		evas_object_show(genlist);

		if (list->items != NULL && list->item_size > 0){
			int i;
			for(i = 0; i < list->item_size; i++){
				elm_genlist_item_append(genlist, itc, list->items[i], NULL, ELM_GENLIST_ITEM_NONE, NULL, NULL);
			}
		}

		elm_genlist_item_class_free(itc);
	}

    evas_object_show(popup);
}


void iap_common_popup(Evas_Object *parent, const char *type, const char *data)
{
	char *body = (char *)data;

	Evas_Object *popup;
	Evas_Object *btn;

	if (!strcmp(type, "error")){
		popup = _iap_form_popup_add(parent, "Error", body);
	} else if (!strcmp(type, "notice")){
		popup = _iap_form_popup_add(parent, "Notice", body);
	} else if (!strcmp(type, "info")){
		popup = _iap_form_popup_add(parent, "Info", body);
	} else {
		popup = _iap_form_popup_add(parent, type, body);
	}

	ad->popup = popup;

	evas_object_event_callback_add(popup, EVAS_CALLBACK_DEL, NULL, NULL);
	evas_object_size_hint_weight_set(popup, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);


	btn = elm_button_add(popup);
	elm_object_text_set(btn, "Ok");
	elm_object_part_content_set( popup, "button1", btn);
	evas_object_smart_callback_add(btn, "clicked", _popup_btn_cancel_cb, NULL);
	evas_object_show(btn);

    evas_object_show(popup);

}

void iap_popup_loading(bool flag)
{
    if( ad == NULL )
    {
        _ERR("loading popup. context is NULL");
        return;
    }

    if( !ad->loading_popup )
    {
        _init_loading();
    }

    if( ad->loading_popup ) {
        if( flag ) {
            if( !ad->is_popup_show )
            {
                evas_object_show( ad->loading_popup );
                ad->is_popup_show = true;

                _DBG("loading popup : SHOW");
            }
        } else {
            if( ad->is_popup_show )
            {
                evas_object_hide( ad->loading_popup );
                ad->is_popup_show = false;

                _DBG("loading popup : HIDE");
            }
        }
    }
}

void iap_popup_loading_timer(bool flag, double timeout)
{
    if( ad == NULL )
    {
        _ERR("loading popup. context is NULL");
        return;
    }

    if( !ad->loading_popup )
    {
        _init_loading();
    }

    if( ad->loading_popup ) {
        if( flag ) {
            if( !ad->is_popup_show )
            {
                evas_object_show( ad->loading_popup );
                ad->is_popup_show = true;

                _DBG("loading popup : SHOW");
            }
            if (ad->timer){
            	ecore_timer_del(ad->timer);
            }
            if (!(ad->is_popup_main_loop)){
            	//ad->timer = ecore_timer_loop_add(timeout, _timeOut_timer_cb, NULL);
            	//ad->is_popup_main_loop = true;
            	//ecore_main_loop_begin();
            	_DBG("called ecore_main_loop_begin()");
//        		int ret = ecore_main_loop_nested_get();
//        		if( ret == 0){
//        			_DBG(">>  ecore_main_loop is not running  <<");
//        			ad->is_popup_main_loop = true;
//        			ecore_main_loop_begin();
//        		}else
//        			_DBG(">>  ecore_main_loop is running  <<");
            }
        } else {
            if( ad->is_popup_show )
            {
                evas_object_hide( ad->loading_popup );
                ad->is_popup_show = false;

                _DBG("loading popup : HIDE");
            }
        }
    }
}


void iap_popup_purchase_success(Evas_Object *parent, const char *title, const char *body, void *data)
{
	purchase_s* purchase = (purchase_s *)data;

	Evas_Object *popup;
	Evas_Object *btn;

	char buf[512] = {0,};
	char *url = NULL;

	if (purchase) {
		snprintf(buf, 512, "%s?purchaseID=%s&param1=%s&param2=%s&param3=%s&param4=%s&param5=%s",
				purchase->ticket_verify_url,
				purchase->ticket_purchase_id,
				purchase->ticket_param1,
				purchase->ticket_param2,
				purchase->ticket_param3,
				purchase->ticket_param4,
				purchase->ticket_param5
		);

		url = malloc(sizeof(buf));
		memset(url, 0X00, sizeof(buf));
		strcpy(url, buf);
	}

	_INFO("URL : %s", url);

	popup = _iap_form_popup_add(parent, title, body);
	ad->popup = popup;

	evas_object_event_callback_add(popup, EVAS_CALLBACK_DEL, NULL, NULL);
	evas_object_size_hint_weight_set(popup, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);

	btn = elm_button_add(popup);
	elm_object_text_set(btn, "Cancel");
	elm_object_part_content_set( popup, "button1", btn);
	evas_object_smart_callback_add(btn, "clicked", _popup_btn_cancel_cb, NULL);
	evas_object_show(btn);

	if (url) {
		btn = elm_button_add(popup);
		elm_object_text_set(btn, "Confirm");
		elm_object_part_content_set( popup, "button2", btn);
		evas_object_smart_callback_add(btn, "clicked", _popup_btn_purchase_verify_url_open, url);
		evas_object_show(btn);
	}

    evas_object_show(popup);
}


void _init_loading() {

    Evas_Object *box;
    Evas_Object *label;
    Evas_Object *progressbar;

    if (ad->loading_popup)
        return;

    ad->loading_popup = elm_popup_add(ad->win);
//    ea_object_event_callback_add(ad->loading_popup, EA_CALLBACK_BACK, ea_popup_back_cb, NULL);
    evas_object_size_hint_weight_set(ad->loading_popup, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
    evas_object_size_hint_min_set(ad->loading_popup, 480, 96);
    evas_object_size_hint_max_set(ad->loading_popup, 480, 96);

    box = elm_box_add(ad->loading_popup);
    evas_object_size_hint_weight_set(box, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
    evas_object_size_hint_align_set(box, EVAS_HINT_FILL, EVAS_HINT_FILL);
    evas_object_size_hint_min_set(box, 480, 96);
    evas_object_size_hint_max_set(box, 480, 96);
    elm_box_horizontal_set(box, EINA_TRUE);
    elm_object_content_set(ad->loading_popup, box);
    evas_object_show(box);

    Evas_Object *gd;
    gd = elm_grid_add (box);
    evas_object_size_hint_weight_set(gd, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
    evas_object_size_hint_align_set(gd, EVAS_HINT_FILL, EVAS_HINT_FILL);
    evas_object_size_hint_min_set(gd, 480, 96);
    evas_object_size_hint_max_set(gd, 480, 96);
    elm_box_pack_end(box, gd);
    evas_object_show(gd);

    progressbar = elm_progressbar_add(gd);
    elm_object_style_set(progressbar, "process_medium");
    evas_object_size_hint_align_set(progressbar, 0.0, 0.5);
    elm_progressbar_pulse(progressbar, EINA_TRUE);
    elm_grid_pack(gd, progressbar, 0, 0, 26, 96);
    evas_object_show(progressbar);

    Evas_Object *labelBox;
    labelBox = elm_box_add(gd);
    evas_object_size_hint_weight_set(labelBox, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
    evas_object_size_hint_align_set(labelBox, EVAS_HINT_FILL, 0.5);
    evas_object_size_hint_min_set(labelBox, 96, 96);
    evas_object_size_hint_max_set(labelBox, 96, 96);
    elm_box_horizontal_set(labelBox, EINA_TRUE);
    elm_grid_pack(gd, labelBox, 20, 0, 96, 96);
    evas_object_show(labelBox);

    label = elm_label_add(labelBox);
    evas_object_size_hint_weight_set(label, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
    evas_object_size_hint_align_set(label, EVAS_HINT_FILL, 0.5);
    elm_object_content_set(labelBox, label);
    elm_object_domain_translatable_part_text_set(label, "elm.text", NULL, "LOADING");
    elm_box_pack_end(labelBox, label);
    evas_object_show(label);

    evas_object_data_set(ad->loading_popup, "progressbar", progressbar);
    evas_object_show(ad->loading_popup);

    ad->is_popup_show = true;
}

Evas_Object *
_iap_form_popup_add( Evas_Object* parent, const char* title, const char *data)
{
    Evas_Object *popup = NULL;

    popup = elm_popup_add( parent );
    if( !popup )
    {
        return NULL;
    }

    // Title
    evas_object_size_hint_weight_set( popup, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND );
    if( title != NULL )
    {
        elm_object_part_text_set( popup, "title,text", title);
    }

    // Body
    if( data )
    {
        elm_object_text_set( popup, data );
        elm_popup_content_text_wrap_type_set(popup, ELM_WRAP_WORD);
    }

//    ea_object_event_callback_add(popup, EA_CALLBACK_BACK, NULL, (void *)data);

    return popup;
}

void
_popup_btn_confirm_cb( void* data, Evas_Object* obj, void* event ){

	char *target = (char *)data;
	char *value = NULL;


	if (!strcmp(target, IAP_SEARCH_OPTION_MCC)){
		value = (char *)elm_entry_entry_get(ad->popup_ef);

		if (value) {
			strcpy(search_config->mcc, value);
			elm_entry_entry_set(control_object->mcc, value);
		}
	} else if (!strcmp(target, IAP_SEARCH_OPTION_MNC)){
		value = (char *)elm_entry_entry_get(ad->popup_ef);

		if (value) {
			strcpy(search_config->mnc, value);
			elm_entry_entry_set(control_object->mnc, value);
		}
	} else if (!strcmp(target, IAP_SEARCH_OPTION_ITEM_GROUP_ID)){
		value = (char *)elm_entry_entry_get(ad->popup_ef);

		if (value) {
			strcpy(search_config->item_group_id, value);
			elm_entry_entry_set(control_object->item_group_id, value);
		}
	} else if (!strcmp(target, IAP_SEARCH_OPTION_ITEM_TYPE_CODE)){

	}

	evas_object_del(ad->popup);
}

void
_popup_btn_cancel_cb( void* data, Evas_Object* obj, void* event ){
	evas_object_del(ad->popup);
}

void
_btn_select_item_type_cb(void* data, Evas_Object* obj, void* event ){
	item_type_s *item = (item_type_s *)data;

	if (item != NULL){
		strcpy(search_config->item_type_code, item->value);
		elm_entry_entry_set(control_object->item_type_code, item->value);

		free_item_type();
	}
	if (ad->popup){
		evas_object_del(ad->popup);
	}
}


char*
_gl_get_item_type_text_cb(void *data, Evas_Object *obj, const char *part)
{
	item_type_s *item = (item_type_s *)data;

	if (item) {
		if (!strcmp(part, "elm.text")){
			return strdup(item->name);
		} else {
			return NULL;
		}
	} else {
		return NULL;
	}
}

Evas_Object*
_gl_get_item_type_object_cb(void *data, Evas_Object *obj, const char *part)
{
	item_type_s *item = (item_type_s *)data;

	Evas_Object *content = NULL;
	Evas_Object *ic;
	Evas_Object *btn;

	ic = elm_layout_add(obj);

	_INFO(" part  : %s", part);

	if(get_iap_resolution() == DEVICE_RESOLUTION_WVGA)
	{
		if (!strcmp(part, "elm.swallow.icon")){  // 2.3

			btn = elm_button_add(obj);
			elm_layout_theme_set(ic, "layout", "list/A/right.icon", "default");
			elm_object_text_set(btn, "SELECT");
			evas_object_size_hint_weight_set(btn, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
			evas_object_size_hint_align_set( btn, EVAS_HINT_FILL, EVAS_HINT_FILL );
			evas_object_smart_callback_add(btn, "clicked", _btn_select_item_type_cb, item);
			elm_layout_content_set(ic, "elm.swallow.content", btn);
			evas_object_size_hint_min_set(btn, 180, 0);
			evas_object_show(btn);

		} else if (!strcmp(part, "elm.swallow.end")){  // 2.4

			btn = elm_button_add(obj);
			elm_layout_theme_set(ic, "layout", "list/A/right.icon", "default");
			elm_object_text_set(btn, "SELECT");
			evas_object_size_hint_weight_set(btn, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
			evas_object_size_hint_align_set( btn, EVAS_HINT_FILL, EVAS_HINT_FILL );
			evas_object_smart_callback_add(btn, "clicked", _btn_select_item_type_cb, item);
			elm_layout_content_set(ic, "elm.swallow.content", btn);
			evas_object_size_hint_min_set(btn, 180, 0);
			evas_object_show(btn);
		}
		else {

			return NULL;
		}
	} else if(get_iap_resolution() == DEVICE_RESOLUTION_HD){

		if (!strcmp(part, "elm.swallow.end")){  // 2.4

			btn = elm_button_add(obj);
			elm_layout_theme_set(ic, "layout", "list/A/right.icon", "default");
			elm_object_text_set(btn, "SELECT");
			evas_object_size_hint_weight_set(btn, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
			evas_object_size_hint_align_set( btn, EVAS_HINT_FILL, EVAS_HINT_FILL );
			evas_object_smart_callback_add(btn, "clicked", _btn_select_item_type_cb, item);
			elm_layout_content_set(ic, "elm.swallow.content", btn);
			evas_object_size_hint_min_set(btn, 180, 0);
			evas_object_show(btn);

		} else {

			return NULL;
		}
	}

	evas_object_show(ic);

    content = ic;

	return content;
}

char*
_gl_get_country_text_cb(void *data, Evas_Object *obj, const char *part)
{
	country_s *item = (country_s *)data;

	if (item) {
		if (!strcmp(part, "elm.text")){
			return strdup(item->name);
		} else {
			return NULL;
		}
	} else {
		return NULL;
	}
}

Evas_Object*
_gl_get_country_data_cb(void *data, Evas_Object *obj, const char *part)
{
	_INFO(" _gl_get_country_data_cb() ");
	country_s *item = (country_s *)data;
	Evas_Object *content = NULL;
	Evas_Object *ic;
	Evas_Object *btn;

	ic = elm_layout_add(obj);

	_INFO(" part  : %s", part);

	if(get_iap_resolution() == DEVICE_RESOLUTION_WVGA)
	{
		if (!strcmp(part, "elm.swallow.icon")){ 	// 2.3

			//select country parameter
			request_param_s *param = (request_param_s *)malloc(sizeof(request_param_s));
			memset(param, 0X00, sizeof(request_param_s));

			strcpy(param->mode, search_config->mode);
			strcpy(param->mcc, item->mcc);
			strcpy(param->mnc, get_hash_from_mnc(item->mcc));

			//Button
			btn = elm_button_add(obj);
			elm_layout_theme_set(ic, "layout", "list/A/right.icon", "default");
			elm_object_text_set(btn, "SELECT");
			evas_object_size_hint_weight_set(btn, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
			evas_object_size_hint_align_set( btn, EVAS_HINT_FILL, EVAS_HINT_FILL );
			evas_object_smart_callback_add(btn, "clicked", _btn_select_country_cb, param);
			elm_layout_content_set(ic, "elm.swallow.content", btn);
			evas_object_size_hint_min_set(btn, 180, 0);
			evas_object_show(btn);

		} else if (!strcmp(part, "elm.swallow.end")){ 	// 2.4
			//select country parameter
			request_param_s *param = (request_param_s *)malloc(sizeof(request_param_s));
			memset(param, 0X00, sizeof(request_param_s));

			strcpy(param->mode, search_config->mode);
			strcpy(param->mcc, item->mcc);
			strcpy(param->mnc, get_hash_from_mnc(item->mcc));

			//Button
			btn = elm_button_add(obj);
			elm_layout_theme_set(ic, "layout", "list/A/right.icon", "default");
			elm_object_text_set(btn, "SELECT");
			evas_object_size_hint_weight_set(btn, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
			evas_object_size_hint_align_set( btn, EVAS_HINT_FILL, EVAS_HINT_FILL );
			evas_object_smart_callback_add(btn, "clicked", _btn_select_country_cb, param);
			elm_layout_content_set(ic, "elm.swallow.content", btn);
			evas_object_size_hint_min_set(btn, 180, 0);
			evas_object_show(btn);

		} else {
			return NULL;
		}

	}else if(get_iap_resolution() == DEVICE_RESOLUTION_HD){

		if (!strcmp(part, "elm.swallow.end")){ 	// 2.4
			//select country parameter
			request_param_s *param = (request_param_s *)malloc(sizeof(request_param_s));
			memset(param, 0X00, sizeof(request_param_s));

			strcpy(param->mode, search_config->mode);
			strcpy(param->mcc, item->mcc);
			strcpy(param->mnc, get_hash_from_mnc(item->mcc));

			//Button
			btn = elm_button_add(obj);
			elm_layout_theme_set(ic, "layout", "list/A/right.icon", "default");
			elm_object_text_set(btn, "SELECT");
			evas_object_size_hint_weight_set(btn, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
			evas_object_size_hint_align_set( btn, EVAS_HINT_FILL, EVAS_HINT_FILL );
			evas_object_smart_callback_add(btn, "clicked", _btn_select_country_cb, param);
			elm_layout_content_set(ic, "elm.swallow.content", btn);
			evas_object_size_hint_min_set(btn, 180, 0);
			evas_object_show(btn);

		} else {

			return NULL;
		}
	}

	evas_object_show(ic);
    content = ic;

	return content;
}

void _btn_select_country_cb( void* data, Evas_Object* obj, void* event ){
	_INFO(" _btn_select_country_cb() ");

	if (data != NULL && ad->mode == atoi(MODE_DEVELOPER)){
		_INFO(" test ");
		request_param_s *param = (request_param_s *)data;
		_INFO(" test ");
		char *mnc = get_hash_from_mnc(param->mcc);
		if (mnc == NULL){
			mnc = "";
		}
		_INFO(" test ");
		elm_entry_entry_set(control_object->mcc, param->mcc);
		elm_entry_entry_set(control_object->mnc, mnc);
		_INFO(" test ");
		strcpy(search_config->mcc, param->mcc);
		strcpy(search_config->mnc, mnc);
		_INFO(" test ");
		evas_object_focus_set(control_object->mcc, EINA_TRUE);
	}
	if (ad->popup){
		_INFO(" test ");
		evas_object_del(ad->popup);
	}
	_INFO(" test ");
}

void _entry_click_cb(void *data, Evas_Object *obj, void *event_info){

	elm_object_domain_translatable_part_text_set(obj, "elm.guide", "sys_string", "Input code"); // Add guide text to elm_entry.
}

Eina_Bool _timeOut_timer_cb(void* data){

	if (ad->is_popup_main_loop){
		_DBG("[IAP_Sample] ecore_main_loop_quit ");
		ecore_main_loop_quit();
		ad->is_popup_main_loop = false;
	}

    if (ad->timer){
    	ecore_timer_del(ad->timer);
    }

	iap_popup_loading(false);

    return ECORE_CALLBACK_CANCEL;
}

void
_popup_btn_purchase_verify_url_open( void* data, Evas_Object* obj, void* event ){
	_DBG("launch tizen.internet");

	evas_object_del(ad->popup);

    app_control_h app_handle;
    app_control_create( &app_handle );
    app_control_set_app_id(app_handle, "tizen.internet" );
    app_control_set_uri(app_handle, (char *)data);
    app_control_set_operation(app_handle, "http://tizen.org/appcontrol/operation/view");
    app_control_send_launch_request(app_handle, NULL, NULL);
    app_control_destroy(app_handle);

	if (data) {
		free(data);
	}
}
