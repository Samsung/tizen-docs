/*
 * Copyright (c) 2014 Samsung Electronics Co., Ltd All Rights Reserved
 *
 * Licensed under the Apache License, Version 2.0 (the License);
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an AS IS BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "dbg.h"
#include "define.h"
#include <system_info.h>

#define DEVICE_RESOLUTION_WVGA 480 * 800
#define DEVICE_RESOLUTION_HD 720 * 1280

//Eina_Hash* newHashMap();

static void
_map_entry_free_cb(void *data);

static void
_closeHashMap(Eina_Hash* map);

static void
_hashMapPut(Eina_Hash* map, const void* key , const void* value);

static void *
_hashMapGet(Eina_Hash* map, const void* key);

int init_control_object(){

	if (control_object == NULL){
		control_object = malloc(sizeof(control_object_s));
		memset(control_object, 0X00, sizeof(control_object_s));
	}
	if (control_object == NULL){
		return -1;
	}

	return 0;
}

int init_configuration(){

	if (search_config == NULL){
		search_config = malloc(sizeof(search_config_s));
		memset(search_config, 0x00, sizeof(search_config_s));

		//default normal mode
		strcpy(search_config->mode, "0");
		ad->mode = 0;
	}

	return 0;
}

int free_configuration(){

	if (search_config != NULL){
		memset(search_config, 0X00, sizeof(search_config_s));
		free(search_config);
		search_config = NULL;
	}

	return 0;
}

Eina_Hash* newHashMap(){
	return eina_hash_string_superfast_new(_map_entry_free_cb);
}

void _map_entry_free_cb(void *data){
	if( data != NULL ){
		free(data);
		data=NULL;
	}
}

void _closeHashMap(Eina_Hash* map){
	if( map != NULL ){
		eina_hash_free(map);
	}
	map = NULL;
}

void _hashMapPut(Eina_Hash* map, const void* key , const void* value){
	if( key == NULL ){
		return ;
	}else if( value == NULL ){
		value = "";
	}

	char* oldValue = NULL;
	oldValue = eina_hash_set(map, key ,strdup(value));
	if (!oldValue){
		//_DBG("Not found for %s, Creating new entry", key);
	}else{
		//_DBG("key[%s] is new value[%s], old value[%s]", key, value, oldValue);
		free(oldValue);
	}
}

void * _hashMapGet(Eina_Hash* map, const void* key){
	void* val = eina_hash_find(	map, key );
	if( val == NULL ){
		return "";
	}else{
		return val;
	}
}

void init_country_hash(){

	if (hash_country == NULL){
		hash_country = newHashMap();
	}

	// init country mnc
	_hashMapPut(hash_country, (char *)"111", "1");
	_hashMapPut(hash_country, (char *)"631", "01");
	_hashMapPut(hash_country, (char *)"365", "20");
	_hashMapPut(hash_country, (char *)"276", "01");
	_hashMapPut(hash_country, (char *)"424", "02");
	_hashMapPut(hash_country, (char *)"722", "01");
	_hashMapPut(hash_country, (char *)"283", "01");
	_hashMapPut(hash_country, (char *)"505", "01");
	_hashMapPut(hash_country, (char *)"232", "01");
	_hashMapPut(hash_country, (char *)"206", "01");
	_hashMapPut(hash_country, (char *)"284", "01");
	_hashMapPut(hash_country, (char *)"218", "03");
	_hashMapPut(hash_country, (char *)"257", "01");
	_hashMapPut(hash_country, (char *)"724", "02");
	_hashMapPut(hash_country, (char *)"302", "220");
	_hashMapPut(hash_country, (char *)"228", "01");
	_hashMapPut(hash_country, (char *)"730", "01");
	_hashMapPut(hash_country, (char *)"460", "0");
	_hashMapPut(hash_country, (char *)"732", "101");
	_hashMapPut(hash_country, (char *)"712", "01");
	_hashMapPut(hash_country, (char *)"368", "01");
	_hashMapPut(hash_country, (char *)"280", "01");
	_hashMapPut(hash_country, (char *)"230", "01");
	_hashMapPut(hash_country, (char *)"262", "01");
	_hashMapPut(hash_country, (char *)"366", "01");
	_hashMapPut(hash_country, (char *)"238", "01");
	_hashMapPut(hash_country, (char *)"370", "01");
	_hashMapPut(hash_country, (char *)"740", "0");
	_hashMapPut(hash_country, (char *)"602", "01");
	_hashMapPut(hash_country, (char *)"214", "01");
	_hashMapPut(hash_country, (char *)"248", "01");
	_hashMapPut(hash_country, (char *)"244", "03");
	_hashMapPut(hash_country, (char *)"208", "0");
	_hashMapPut(hash_country, (char *)"628", "01");
	_hashMapPut(hash_country, (char *)"234", "10");
	_hashMapPut(hash_country, (char *)"282", "01");
	_hashMapPut(hash_country, (char *)"202", "01");
	_hashMapPut(hash_country, (char *)"704", "01");
	_hashMapPut(hash_country, (char *)"454", "0");
	_hashMapPut(hash_country, (char *)"708", "001");
	_hashMapPut(hash_country, (char *)"219", "01");
	_hashMapPut(hash_country, (char *)"216", "01");
	_hashMapPut(hash_country, (char *)"510", "01");
	_hashMapPut(hash_country, (char *)"404", "01");
	_hashMapPut(hash_country, (char *)"272", "01");
	_hashMapPut(hash_country, (char *)"432", "11");
	_hashMapPut(hash_country, (char *)"425", "01");
	_hashMapPut(hash_country, (char *)"222", "01");
	_hashMapPut(hash_country, (char *)"338", "070");
	_hashMapPut(hash_country, (char *)"416", "01");
	_hashMapPut(hash_country, (char *)"440", "01");
	_hashMapPut(hash_country, (char *)"401", "01");
	_hashMapPut(hash_country, (char *)"639", "01");
	_hashMapPut(hash_country, (char *)"450", "1");
	_hashMapPut(hash_country, (char *)"419", "02");
	_hashMapPut(hash_country, (char *)"246", "01");
	_hashMapPut(hash_country, (char *)"270", "01");
	_hashMapPut(hash_country, (char *)"247", "01");
	_hashMapPut(hash_country, (char *)"604", "0");
	_hashMapPut(hash_country, (char *)"334", "010");
	_hashMapPut(hash_country, (char *)"294", "01");
	_hashMapPut(hash_country, (char *)"278", "01");
	_hashMapPut(hash_country, (char *)"297", "01");
	_hashMapPut(hash_country, (char *)"609", "07");
	_hashMapPut(hash_country, (char *)"502", "12");
	_hashMapPut(hash_country, (char *)"621", "02");
	_hashMapPut(hash_country, (char *)"710", "20");
	_hashMapPut(hash_country, (char *)"204", "02");
	_hashMapPut(hash_country, (char *)"242", "01");
	_hashMapPut(hash_country, (char *)"530", "01");
	_hashMapPut(hash_country, (char *)"714", "01");
	_hashMapPut(hash_country, (char *)"716", "06");
	_hashMapPut(hash_country, (char *)"515", "01");
	_hashMapPut(hash_country, (char *)"260", "01");
	_hashMapPut(hash_country, (char *)"330", "110");
	_hashMapPut(hash_country, (char *)"1000", "01");
	_hashMapPut(hash_country, (char *)"268", "01");
	_hashMapPut(hash_country, (char *)"744", "01");
	_hashMapPut(hash_country, (char *)"427", "01");
	_hashMapPut(hash_country, (char *)"226", "01");
	_hashMapPut(hash_country, (char *)"250", "01");
	_hashMapPut(hash_country, (char *)"420", "01");
	_hashMapPut(hash_country, (char *)"634", "01");
	_hashMapPut(hash_country, (char *)"525", "01");
	_hashMapPut(hash_country, (char *)"706", "01");
	_hashMapPut(hash_country, (char *)"220", "01");
	_hashMapPut(hash_country, (char *)"231", "01");
	_hashMapPut(hash_country, (char *)"293", "01");
	_hashMapPut(hash_country, (char *)"240", "01");
	_hashMapPut(hash_country, (char *)"417", "01");
	_hashMapPut(hash_country, (char *)"520", "01");
	_hashMapPut(hash_country, (char *)"374", "12");
	_hashMapPut(hash_country, (char *)"605", "01");
	_hashMapPut(hash_country, (char *)"286", "01");
	_hashMapPut(hash_country, (char *)"466", "01");
	_hashMapPut(hash_country, (char *)"255", "01");
	_hashMapPut(hash_country, (char *)"748", "0");
	_hashMapPut(hash_country, (char *)"734", "01");
	_hashMapPut(hash_country, (char *)"452", "01");
	_hashMapPut(hash_country, (char *)"655", "01");
}

void free_country_hash(){
	if (hash_country != NULL){
		_closeHashMap(hash_country);
	}
}

char* get_hash_from_mnc(const char* mcc){
	return (char *)_hashMapGet(hash_country, (char *)mcc);
}


int create_search_parameter(request_param_s* param){

	if (param){
		if (search_config->mode){
			if (!strcmp(search_config->mode, MODE_NORMAL)){
				strcpy(param->item_group_id, strdup(DEFINE_PRD_ITEM_GROUP_ID));
				strcpy(param->item_type_cd, strdup(DEFINE_PRD_ITEM_TYPE_CODE));
				strcpy(param->language_cd, strdup(DEFINE_PRD_LANGUAGE_CODE));
				param->start_number = 1;
				param->end_number = NUM_OF_ITEMS;
				strcpy(param->start_date, strdup(DEFINE_PRD_START_DATE));
				strcpy(param->end_date, strdup(DEFINE_PRD_END_DATE));
				strcpy(param->mode, strdup(MODE_NORMAL));
				strcpy(param->mcc, strdup(""));
				strcpy(param->mnc, strdup(""));
				strcpy(param->item_id, strdup(""));
				strcpy(param->item_name, strdup(""));
			} else {
				if (search_config->mcc) {
					strcpy(param->mcc, strdup(search_config->mcc));
				}
				if (search_config->mnc) {
					strcpy(param->mnc, strdup(search_config->mnc));
				}
				strcpy(param->item_group_id, strdup(search_config->item_group_id));
				strcpy(param->item_type_cd, strdup(search_config->item_type_code));
				strcpy(param->language_cd, strdup(DEFINE_DEV_LANGUAGE_CODE));
				param->start_number = 1;
				param->end_number = NUM_OF_ITEMS;
				strcpy(param->start_date, strdup(DEFINE_DEV_START_DATE));
				strcpy(param->end_date, strdup(DEFINE_DEV_END_DATE));
				strcpy(param->mode, strdup(MODE_DEVELOPER));
				strcpy(param->item_id, strdup(""));
				strcpy(param->item_name, strdup(""));
			}
		} else {
			return -1;
		}
	} else {
		return -1;
	}

	return 0;
}

void free_search_parameter(request_param_s* param){

	if (param){
		memset(param, 0X00, sizeof(request_param_s));
		free(param);
		param = NULL;
	}
}

void init_item_type(){
	item_types[0] = (item_type_s *)malloc(sizeof(item_type_s));
	memset(item_types[0], 0X00, sizeof(item_type_s));
	item_types[0]->id = 0;
	strcpy(item_types[0]->name, ITEM_TYPE_NAME_CONSUMABLE);
	strcpy(item_types[0]->value, ITEM_TYPE_CODE_CONSUMABLE);

	item_types[1] = (item_type_s *)malloc(sizeof(item_type_s));
	memset(item_types[1], 0X00, sizeof(item_type_s));
	item_types[1]->id = 1;
	strcpy(item_types[1]->name, ITEM_TYPE_NAME_NON_CONSUMABLE);
	strcpy(item_types[1]->value, ITEM_TYPE_CODE_NON_CONSUMABLE);

	item_types[2] = (item_type_s *)malloc(sizeof(item_type_s));
	memset(item_types[2], 0X00, sizeof(item_type_s));
	item_types[2]->id = 2;
	strcpy(item_types[2]->name, ITEM_TYPE_NAME_SUBSCRIPTION);
	strcpy(item_types[2]->value, ITEM_TYPE_CODE_SUBSCRIPTION);

	item_types[3] = (item_type_s *)malloc(sizeof(item_type_s));
	memset(item_types[3], 0X00, sizeof(item_type_s));
	item_types[3]->id = 3;
	strcpy(item_types[3]->name, ITEM_TYPE_NAME_ALL);
	strcpy(item_types[3]->value, ITEM_TYPE_CODE_ALL);

}

void free_item_type(){
	if (item_types[0]){
		free(item_types[0]);
	}
	if (item_types[1]){
		free(item_types[1]);
	}
	if (item_types[2]){
		free(item_types[2]);
	}
	if (item_types[3]){
		free(item_types[3]);
	}
}

void init_iap_result(){
	if (!iap_result){
		iap_result = malloc(sizeof(iap_result_s));
		memset(iap_result, 0X00, sizeof(iap_result_s));

		iap_result->country_list_result = NULL;
		iap_result->item_list_result = NULL;
		iap_result->purchase_result = NULL;
	}
}

void free_iap_result(iap_menu_e menu){
	int index = 0;

	if (iap_result) {
		if (iap_result->country_list_result && menu == FUNC_GET_COUNTRY_LIST){
			if (iap_result->country_list_result->item_size > 0){
				for (index = 0; index < iap_result->country_list_result->item_size; index++){
					if (iap_result->country_list_result->items[index]){
						free(iap_result->country_list_result->items[index]);
						iap_result->country_list_result->items[index] = NULL;
					}
					iap_result->country_list_result->item_size--;
				}
			}
			free(iap_result->country_list_result);
			iap_result->country_list_result = NULL;
		}

		if (iap_result->item_list_result && (menu == FUNC_GET_ITEM_LIST || menu == FUNC_GET_PURCHASED_ITEM_LIST)){
			if (iap_result->item_list_result->item_size > 0){
				for (index = 0; index < iap_result->item_list_result->item_size; index++){
					if (iap_result->item_list_result->items[index]){
						free(iap_result->item_list_result->items[index]);
						iap_result->item_list_result->items[index] = NULL;
					}
					iap_result->item_list_result->item_size--;
				}
			}
			free(iap_result->item_list_result);
			iap_result->item_list_result = NULL;
		}

		if (iap_result->purchase_result && menu == FUNC_PURCHASE){
			free(iap_result->purchase_result);
			iap_result->purchase_result = NULL;
		}
	}
}

char* get_iap_result_message(const char* result_code){

	if (!strcmp(RESULT_SUCCESS, result_code)){
		return "Success";
	}
	if (!strcmp(RESULT_ERROR_200, result_code)){
		return "Network error";
	}
	if (!strcmp(RESULT_ERROR_2001, result_code)){
		return "Service not ready for this country";
	}
	if (!strcmp(RESULT_ERROR_1000, result_code)){
		return "Process error";
	}
	if (!strcmp(RESULT_ERROR_9201, result_code)){
		return "Item group id not found";
	}
	if (!strcmp(RESULT_ERROR_9207, result_code)){
		return "Item id not found";
	}
	if (!strcmp(RESULT_ERROR_9502, result_code)){
		return "Invalid request param";
	}
	if (!strcmp(RESULT_ERROR_100, result_code)){
		return "User cancel";
	}
	if (!strcmp(RESULT_ERROR_5600, result_code)){
		return "PG error";
	}
	if (!strcmp(RESULT_ERROR_9291, result_code)){
		return "No Reorder Item";
	}
	if (!strcmp(RESULT_ERROR_9292, result_code)){
		return "Update In-App Purchase Client";
	}
	return "Unknow error";
}

int get_iap_resolution()
{
    // Resolution Set
	int screenWidth, screenHeight;
	int retW = system_info_get_platform_int("http://tizen.org/feature/screen.width", &screenWidth);
	int retH = system_info_get_platform_int("http://tizen.org/feature/screen.height", &screenHeight);
	_DBG("[IAP_Sample] device resolution = width : %d / height: %d", screenWidth, screenHeight);

	_DBG("[IAP_Sample] screenWidth : %d ", screenWidth);
	return screenWidth;
}
