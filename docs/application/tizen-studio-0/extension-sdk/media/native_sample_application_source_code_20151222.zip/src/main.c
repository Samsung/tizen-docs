/*
 * Copyright (c) 2014 Samsung Electronics Co., Ltd All Rights Reserved
 *
 * Licensed under the Apache License, Version 2.0 (the License);
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an AS IS BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */



#include <app.h>
#include <vconf.h>
#include <Elementary.h>
#include <runtime_info.h>
#include <efl_extension.h>

#include "dbg.h"
#include "define.h"
#include "form.h"
#include "common.h"
#include "popup.h"

static void win_delete_request_cb(void *data , Evas_Object *obj , void *event_info)
{
	LOGI("[IAP_SAMPLE] win_delete_request_cb()");
}

static Eina_Bool keydown_cb(void *data , int type , void *event)
{
	LOGI("[IAP_SAMPLE] keydown_cb()");

	appdata_s *ad = data;
	Ecore_Event_Key *ev = event;
	if (!strcmp(ev->keyname, KEY_END)) {

		if (ad->popup) {

			_DBG("ad->popup : %x", ad->popup);

            if( ad->popup )
            {
                evas_object_del(ad->popup);
                ad->popup = NULL;
            }

            return ECORE_CALLBACK_PASS_ON;
		}

		if (ad->is_popup_show) {

			if (ad->loading_popup) {

				_DBG("ad->loading_popup : %x", ad->loading_popup);

				iap_popup_loading(false);

	            if (ad->timer){
	            	ecore_timer_del(ad->timer);
	            }
			}

			return ECORE_CALLBACK_PASS_ON;
		}

		/* Let window go to hide state. */
		elm_win_lower(ad->win);

		return ECORE_CALLBACK_DONE;

	}

	return ECORE_CALLBACK_PASS_ON;
}

static void win_back_cb(void *data, Evas_Object *obj, void *event_info)
{
	LOGI("[IAP_SAMPLE] win_back_cb()");

	elm_exit();
}

static void create_base_gui(appdata_s *ad)
{
	LOGI("[IAP_SAMPLE] create_base_gui()");

	if (iap_create_form(ad) != 0){
		_ERR("iap sample app form create fail.");
		return;
	}

//	Browser_Window_s *browser = NULL;
//	memset(browser, 0X00, sizeof(Browser_Window_s));
//	ad->browser = browser;

	evas_object_smart_callback_add(ad->win, "delete,request", win_delete_request_cb, NULL);

	evas_object_show(ad->win);

	eext_object_event_callback_add(ad->win, EEXT_CALLBACK_BACK, win_back_cb, ad);
	ecore_event_handler_add(ECORE_EVENT_KEY_DOWN, keydown_cb, ad);
}

static bool app_create(void *data)
{
	LOGI("[IAP_SAMPLE] app_create()");

	/* Hook to take necessary actions before main event loop starts
		Initialize UI resources and application's data
		If this function returns true, the main loop of application starts
		If this function returns false, the application is terminated */
	ad = (appdata_s *)data;


	//initialize
	control_object = NULL;
	search_config = NULL;
	hash_country = NULL;
	iap_result = NULL;

	create_base_gui(ad);

	return true;
}

//static void
//app_language_changed(void *data)
//{
////	/* Set the current language */
////	char *locale = vconf_get_str(VCONFKEY_LANGSET);
////	if (locale) elm_language_set(locale);
//
//	char *locale = NULL;
//	runtime_info_get_value_string(RUNTIME_INFO_KEY_LANGUAGE, &locale);
//
//	elm_language_set(locale);
//	free(locale);
//}

static void app_control(app_control_h app_control, void *data)
{
	LOGI("[IAP_SAMPLE] app_control()");
	/* Handle the launch request. */
}

static void app_pause(void *data)
{
	/* Take necessary actions when application becomes invisible. */
}

static void app_resume(void *data)
{
	/* Take necessary actions when application becomes visible. */
}

static void app_terminate(void *data)
{
	/* Release all resources. */
	LOGI("[IAP_SAMPLE] app_terminate()");
}

int main(int argc, char *argv[])
{
	LOGI("[IAP_SAMPLE] main()");

	appdata_s ad = {0,};
#if 0
	app_event_callback_s event_callback;

	event_callback.create = app_create;
	event_callback.terminate = app_terminate;
	event_callback.pause = app_pause;
	event_callback.resume = app_resume;
	event_callback.app_control = app_control;
	event_callback.language_changed = app_language_changed;

	event_callback.low_memory = NULL;
	event_callback.low_battery = NULL;
	event_callback.device_orientation = NULL;
	event_callback.region_format_changed = NULL;

	memset(&ad, 0x0, sizeof(appdata_s));

	int ret = app_efl_main(&argc, &argv, &event_callback, &ad);
	if (ret != APP_ERROR_NONE) {
		LOGE("app_efl_main() is failed. err = %d", ret);
	}
#else
	ui_app_lifecycle_callback_s event_callback = {0,};
	app_event_handler_h handlers[5] = {NULL, };

	event_callback.create = app_create;
	event_callback.terminate = app_terminate;
	event_callback.pause = app_pause;
	event_callback.resume = app_resume;
	event_callback.app_control = app_control;

	memset(&ad, 0x0, sizeof(appdata_s));

	//int ret = app_main(argc, argv, &event_callback, context);
	int ret = ui_app_main(argc, argv, &event_callback, &ad);
	if (ret != APP_ERROR_NONE) {
		LOGE("app_main() is failed. err = %d", ret);
		//dlog_print(DLOG_ERROR, LOG_TAG, "app_main() is failed. err = %d", ret);
	}
#endif


	return ret;
}
