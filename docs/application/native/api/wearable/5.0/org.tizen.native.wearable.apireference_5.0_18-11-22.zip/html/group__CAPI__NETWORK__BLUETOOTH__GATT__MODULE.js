var group__CAPI__NETWORK__BLUETOOTH__GATT__MODULE =
[
    [ "Bluetooth GATT Client", "group__CAPI__NETWORK__BLUETOOTH__GATT__CLIENT__MODULE.html", null ],
    [ "Bluetooth GATT Server", "group__CAPI__NETWORK__BLUETOOTH__GATT__SERVER__MODULE.html", null ]
];