var group__CAPI__MESSAGING__MESSAGES__MODULE =
[
    [ "MMS", "group__CAPI__MESSAGING__MESSAGES__MMS__MODULE.html", null ],
    [ "WAP Push", "group__CAPI__MESSAGING__MESSAGES__PUSH__MODULE.html", null ]
];