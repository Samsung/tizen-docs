var group__CAPI__UIX__VOICE__CONTROL__MODULE =
[
    [ "Voice control command", "group__CAPI__UIX__VOICE__CONTROL__COMMAND__MODULE.html", null ]
];