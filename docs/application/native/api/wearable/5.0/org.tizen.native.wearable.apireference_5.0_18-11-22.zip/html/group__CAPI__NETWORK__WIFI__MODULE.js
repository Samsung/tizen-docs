var group__CAPI__NETWORK__WIFI__MODULE =
[
    [ "Wi-Fi Configuration", "group__CAPI__NETWORK__WIFI__CONFIG__MODULE.html", null ],
    [ "Wi-Fi Management", "group__CAPI__NETWORK__WIFI__MANAGEMENT__MODULE.html", "group__CAPI__NETWORK__WIFI__MANAGEMENT__MODULE" ],
    [ "Wi-Fi Monitor", "group__CAPI__NETWORK__WIFI__MONITOR__MODULE.html", null ],
    [ "Wi-Fi TDLS", "group__CAPI__NETWORK__WIFI__TDLS__MODULE.html", null ]
];