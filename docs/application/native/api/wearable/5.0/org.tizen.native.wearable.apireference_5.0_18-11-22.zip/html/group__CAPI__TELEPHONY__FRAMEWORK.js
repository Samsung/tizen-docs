var group__CAPI__TELEPHONY__FRAMEWORK =
[
    [ "Telephony Information", "group__CAPI__TELEPHONY__INFORMATION.html", "group__CAPI__TELEPHONY__INFORMATION" ]
];