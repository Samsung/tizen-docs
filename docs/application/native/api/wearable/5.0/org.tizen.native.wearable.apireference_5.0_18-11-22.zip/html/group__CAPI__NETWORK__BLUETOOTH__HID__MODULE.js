var group__CAPI__NETWORK__BLUETOOTH__HID__MODULE =
[
    [ "Bluetooth HID Device", "group__CAPI__NETWORK__BLUETOOTH__HID__DEVICE__MODULE.html", null ],
    [ "Bluetooth HID Host", "group__CAPI__NETWORK__BLUETOOTH__HID__HOST__MODULE.html", null ]
];