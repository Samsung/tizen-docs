var group__Eina =
[
    [ "Data Types", "group__Eina__Data__Types__Group.html", "group__Eina__Data__Types__Group" ],
    [ "Event Log Debugging", "group__Eina__Evlog.html", null ],
    [ "Mmap Group", "group__Eina__Mmap__Group.html", null ],
    [ "Thread Queue Group", "group__Eina__Thread__Queue__Group.html", null ],
    [ "Tools", "group__Eina__Tools__Group.html", "group__Eina__Tools__Group" ]
];