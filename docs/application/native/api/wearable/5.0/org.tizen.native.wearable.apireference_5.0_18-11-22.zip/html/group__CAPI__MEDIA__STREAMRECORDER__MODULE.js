var group__CAPI__MEDIA__STREAMRECORDER__MODULE =
[
    [ "Attributes", "group__CAPI__MEDIA__STREAMRECORDER__ATTRIBUTES__MODULE.html", null ],
    [ "Callback", "group__CAPI__MEDIA__STREAMRECORDER__CALLBACK__MODULE.html", null ],
    [ "Capability", "group__CAPI__MEDIA__STREAMRECORDER__CAPABILITY__MODULE.html", null ]
];