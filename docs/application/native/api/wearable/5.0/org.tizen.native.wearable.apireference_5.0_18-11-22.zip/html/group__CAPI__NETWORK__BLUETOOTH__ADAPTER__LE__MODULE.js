var group__CAPI__NETWORK__BLUETOOTH__ADAPTER__LE__MODULE =
[
    [ "Bluetooth LE Adapter for Bluetooth 5.0", "group__CAPI__NETWORK__BLUETOOTH__ADAPTER__LE__50__MODULE.html", null ]
];