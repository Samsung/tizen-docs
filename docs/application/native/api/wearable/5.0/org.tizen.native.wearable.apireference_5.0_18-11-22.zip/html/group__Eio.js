var group__Eio =
[
    [ "Eio Reference helper API", "group__Eio__Helper.html", null ],
    [ "Eio asynchronous API for Eet file.", "group__Eio__Eet.html", null ],
    [ "Eio file and directory monitoring API", "group__Eio__Monitor.html", null ],
    [ "Eio file listing API", "group__Eio__List.html", null ],
    [ "Eio manipulation of eXtended attribute.", "group__Eio__Xattr.html", null ],
    [ "Manipulate an Eina_File asynchronously", "group__Eio__Map.html", null ]
];