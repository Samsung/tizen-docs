var group__CAPI__NETWORK__NFC__TAG__MODULE =
[
    [ "Mifare", "group__CAPI__NETWORK__NFC__TAG__MIFARE__MODULE.html", null ]
];