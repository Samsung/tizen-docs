var group__OPENSRC__SDL__FRAMEWORK =
[
    [ "SDL Tizen", "group__CAPI__SDL__TIZEN__MODULE.html", null ]
];