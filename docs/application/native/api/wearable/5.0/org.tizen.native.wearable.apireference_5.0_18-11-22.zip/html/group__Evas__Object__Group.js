var group__Evas__Object__Group =
[
    [ "Basic Object Manipulation", "group__Evas__Object__Group__Basic.html", null ],
    [ "Extra Object Manipulation", "group__Evas__Object__Group__Extras.html", null ],
    [ "Finding Objects", "group__Evas__Object__Group__Find.html", null ],
    [ "Object Events", "group__Evas__Object__Group__Events.html", null ],
    [ "Object Method Interceptors", "group__Evas__Object__Group__Interceptors.html", null ],
    [ "Size Hints", "group__Evas__Object__Group__Size__Hints.html", null ],
    [ "UV Mapping (Rotation, Perspective, 3D...)", "group__Evas__Object__Group__Map.html", null ]
];