var group__CAPI__EFL__UTIL__MODULE =
[
    [ "EFL UTIL GESTURE", "group__CAPI__EFL__UTIL__GESTURE__MODULE.html", null ],
    [ "EFL UTIL INPUT", "group__CAPI__EFL__UTIL__INPUT__MODULE.html", null ],
    [ "EFL UTIL SCREENSHOT", "group__CAPI__EFL__UTIL__SCREENSHOT__MODULE.html", null ],
    [ "EFL UTIL WINDOW PROPERTY", "group__CAPI__EFL__UTIL__WIN__PROPERTY__MODULE.html", null ]
];