var group__CAPI__SOCIAL__CONTACTS__SVC__MODULE =
[
    [ "Activity", "group__CAPI__SOCIAL__CONTACTS__SVC__ACTIVITY__MODULE.html", null ],
    [ "Common", "group__CAPI__SOCIAL__CONTACTS__SVC__COMMON__MODULE.html", null ],
    [ "Database", "group__CAPI__SOCIAL__CONTACTS__SVC__DATABASE__MODULE.html", null ],
    [ "Filter", "group__CAPI__SOCIAL__CONTACTS__SVC__FILTER__MODULE.html", null ],
    [ "Group", "group__CAPI__SOCIAL__CONTACTS__SVC__GROUP__MODULE.html", null ],
    [ "List", "group__CAPI__SOCIAL__CONTACTS__SVC__LIST__MODULE.html", null ],
    [ "Person", "group__CAPI__SOCIAL__CONTACTS__SVC__PERSON__MODULE.html", null ],
    [ "Phone log", "group__CAPI__SOCIAL__CONTACTS__SVC__PHONELOG__MODULE.html", null ],
    [ "Query", "group__CAPI__SOCIAL__CONTACTS__SVC__QUERY__MODULE.html", null ],
    [ "Record", "group__CAPI__SOCIAL__CONTACTS__SVC__RECORD__MODULE.html", null ],
    [ "SIM", "group__CAPI__SOCIAL__CONTACTS__SVC__SIM__MODULE.html", null ],
    [ "Setting", "group__CAPI__SOCIAL__CONTACTS__SVC__SETTING__MODULE.html", null ],
    [ "View/Property", "group__CAPI__SOCIAL__CONTACTS__SVC__VIEW__MODULE.html", null ],
    [ "vCard", "group__CAPI__SOCIAL__CONTACTS__SVC__VCARD__MODULE.html", null ]
];