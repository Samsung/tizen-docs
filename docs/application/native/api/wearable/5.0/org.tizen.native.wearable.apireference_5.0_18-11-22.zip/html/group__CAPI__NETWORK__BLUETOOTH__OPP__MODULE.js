var group__CAPI__NETWORK__BLUETOOTH__OPP__MODULE =
[
    [ "Bluetooth OPP Client", "group__CAPI__NETWORK__BLUETOOTH__OPP__CLIENT__MODULE.html", null ],
    [ "Bluetooth OPP Server", "group__CAPI__NETWORK__BLUETOOTH__OPP__SERVER__MODULE.html", null ]
];