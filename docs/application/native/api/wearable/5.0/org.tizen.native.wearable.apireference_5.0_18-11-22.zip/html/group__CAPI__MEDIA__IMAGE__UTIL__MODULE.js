var group__CAPI__MEDIA__IMAGE__UTIL__MODULE =
[
    [ "Image Util Encode/Decode", "group__CAPI__MEDIA__IMAGE__UTIL__ENCODE__DECODE__MODULE.html", null ],
    [ "Image Util Transform", "group__CAPI__MEDIA__IMAGE__UTIL__TRANSFORM__MODULE.html", null ]
];