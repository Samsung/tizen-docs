var group__CAPI__UIX__MULTI__ASSISTANT__MODULE =
[
    [ "Multi assistant client", "group__CAPI__UIX__MULTI__ASSISTANT__CLIENT__MODULE.html", null ]
];