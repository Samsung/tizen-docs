var group__CAPI__BASE__UTILS__MODULE =
[
    [ "i18n", "group__CAPI__BASE__UTILS__I18N__MODULE.html", "group__CAPI__BASE__UTILS__I18N__MODULE" ]
];