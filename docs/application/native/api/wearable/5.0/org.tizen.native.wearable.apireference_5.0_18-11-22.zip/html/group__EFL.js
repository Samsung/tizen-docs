var group__EFL =
[
    [ "Ecore", "group__Ecore.html", "group__Ecore" ],
    [ "Edje", "group__Edje.html", "group__Edje" ],
    [ "Eet", "group__Eet.html", "group__Eet" ],
    [ "Eina", "group__Eina.html", "group__Eina" ],
    [ "Eio", "group__Eio.html", "group__Eio" ],
    [ "Eldbus", "group__Eldbus.html", null ],
    [ "Elementary", "group__Elementary.html", "group__Elementary" ],
    [ "Evas", "group__Evas.html", "group__Evas" ]
];