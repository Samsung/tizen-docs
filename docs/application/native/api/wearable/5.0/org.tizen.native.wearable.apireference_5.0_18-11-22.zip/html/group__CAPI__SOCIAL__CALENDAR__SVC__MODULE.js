var group__CAPI__SOCIAL__CALENDAR__SVC__MODULE =
[
    [ "Common", "group__CAPI__SOCIAL__CALENDAR__SVC__COMMON__MODULE.html", null ],
    [ "Database", "group__CAPI__SOCIAL__CALENDAR__SVC__DATABASE__MODULE.html", null ],
    [ "Filter", "group__CAPI__SOCIAL__CALENDAR__SVC__FILTER__MODULE.html", null ],
    [ "List", "group__CAPI__SOCIAL__CALENDAR__SVC__LIST__MODULE.html", null ],
    [ "Query", "group__CAPI__SOCIAL__CALENDAR__SVC__QUERY__MODULE.html", null ],
    [ "Record", "group__CAPI__SOCIAL__CALENDAR__SVC__RECORD__MODULE.html", null ],
    [ "Reminder", "group__CAPI__SOCIAL__CALENDAR__SVC__REMINDER__MODULE.html", null ],
    [ "View/Property", "group__CAPI__SOCIAL__CALENDAR__SVC__VIEW__MODULE.html", null ],
    [ "vCalendar", "group__CAPI__SOCIAL__CALENDAR__SVC__VCALENDAR__MODULE.html", null ]
];