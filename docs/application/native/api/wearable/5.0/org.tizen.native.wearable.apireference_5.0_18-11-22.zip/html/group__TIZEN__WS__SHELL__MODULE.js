var group__TIZEN__WS__SHELL__MODULE =
[
    [ "Tizen WS Shell Quickpanel", "group__TIZEN__WS__SHELL__QUICKPANEL__MODULE.html", null ]
];