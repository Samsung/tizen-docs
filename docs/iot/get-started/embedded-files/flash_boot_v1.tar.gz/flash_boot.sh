sudo fastboot flash partmap bootimage/partmap_artik530_tizen_emmc.txt
sudo fastboot flash setenv bootimage/partition.txt
sudo fastboot flash bootloader bootimage/bootloader.img
sudo fastboot flash env bootimage/params.bin
