var annotated_dup =
[
    [ "dm_lwm2m_context_s", "structdm__lwm2m__context__s.html", "structdm__lwm2m__context__s" ],
    [ "iotbus_spi_config_s", "structiotbus__spi__config__s.html", null ]
];