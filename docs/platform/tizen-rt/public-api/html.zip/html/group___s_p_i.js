var group___s_p_i =
[
    [ "iotbus_spi.h", "iotbus__spi_8h.html", null ],
    [ "iotbus_spi_config_s", "structiotbus__spi__config__s.html", null ],
    [ "iotbus_spi_context_h", "group___s_p_i.html#gac99b32486d9e86b9112d015972d4b984", null ],
    [ "iotbus_spi_mode_e", "group___s_p_i.html#ga80658801a39a1cc6afef5192a320b6df", null ],
    [ "iotbus_spi_close", "group___s_p_i.html#ga262f23eee62fca4be77a1eee609854cf", null ],
    [ "iotbus_spi_open", "group___s_p_i.html#ga7dd00e8f4bdc4a6867a6053fd26a712b", null ],
    [ "iotbus_spi_recv", "group___s_p_i.html#gae95105da541fd691869c0c58eb26a098", null ],
    [ "iotbus_spi_transfer_buf", "group___s_p_i.html#ga04bb1df1281ccdbbd4f394226032f18f", null ],
    [ "iotbus_spi_write", "group___s_p_i.html#ga9b075e13eec22d88c5f42d20c5f1c0f5", null ]
];