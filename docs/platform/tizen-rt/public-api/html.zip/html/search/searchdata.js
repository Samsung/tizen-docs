var indexSectionsWithContent =
{
  0: "acdgilpsu",
  1: "cdis",
  2: "adi",
  3: "cdi",
  4: "i",
  5: "di",
  6: "i",
  7: "acdgilpsu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "typedefs",
  5: "enums",
  6: "enumvalues",
  7: "groups"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Typedefs",
  5: "Enumerations",
  6: "Enumerator",
  7: "Modules"
};

